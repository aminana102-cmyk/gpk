
import { Suspense } from 'react';
import { CheckoutPageContent } from '@/components/checkout/checkout-page-content';

// Using a wrapper component with Suspense to handle searchParams retrieval
// in a client component, which is the recommended pattern in Next.js App Router.
export default function CheckoutPage() {
  return (
    <Suspense fallback={<div className="container mx-auto text-center py-20">Loading Your Order...</div>}>
      <CheckoutPageContent />
    </Suspense>
  );
}
