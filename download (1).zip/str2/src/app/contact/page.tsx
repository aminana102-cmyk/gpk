import type { Metadata } from 'next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MessageCircle, Phone } from 'lucide-react';
import { FadeIn } from '@/components/fade-in';
import { CtaButton } from '@/components/cta-button';

export const metadata: Metadata = {
  title: 'Contact Us',
  description: 'Get in touch with the IPTV THE FOX team. We are here to help with any questions, support requests, or feedback you may have. Contact us via Telegram or WhatsApp for the fastest response.',
};

const TELEGRAM_LINK = 'https://t.me/ZYNN_TV';
const WHATSAPP_LINK = 'https://wa.me/212629095943';

export default function ContactPage() {
  return (
    <div className="container mx-auto px-6 py-12 md:py-16">
      <FadeIn>
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-extrabold font-headline text-primary">
            Get In Touch
          </h1>
          <p className="mt-4 text-lg text-foreground/80">
            We're here to help. Whether you have a question about our service, need technical support, or want to give feedback, our team is ready to assist you.
          </p>
        </div>
      </FadeIn>

      <FadeIn delay={200}>
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <Card className="bg-card border-border/80 hover:border-primary/50 transition-colors duration-300">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <MessageCircle className="h-8 w-8 text-primary" />
                <span className="text-2xl font-headline">Contact on Telegram</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-foreground/80 mb-4">For the fastest support and sales inquiries, please reach out to us on Telegram.</p>
              <CtaButton href={TELEGRAM_LINK} className="w-full" variant="primary">
                Open Telegram
              </CtaButton>
            </CardContent>
          </Card>

          <Card className="bg-card border-border/80 hover:border-primary/50 transition-colors duration-300">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <Phone className="h-8 w-8 text-primary" />
                <span className="text-2xl font-headline">Chat on WhatsApp</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-foreground/80 mb-4">Prefer WhatsApp? No problem. Contact us for any questions you might have.</p>
              <CtaButton href={WHATSAPP_LINK} className="w-full" variant="secondary">
                Open WhatsApp
              </CtaButton>
            </CardContent>
          </Card>
        </div>
      </FadeIn>
    </div>
  );
}
