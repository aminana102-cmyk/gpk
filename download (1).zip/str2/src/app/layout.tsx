
'use client';

import './globals.css';
import { cn } from '@/lib/utils';
import { Toaster } from '@/components/ui/toaster';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { Organization, WebSite } from 'schema-dts';
import { Helmet, HelmetProvider } from 'react-helmet-async';

const organizationSchema: Organization = {
  '@type': 'Organization',
  name: 'IPTV THE FOX',
  url: 'https://iptvthefox.tv', // Replace with your actual domain
  logo: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/10938+(1).webp',
  contactPoint: {
    '@type': 'ContactPoint',
    contactType: 'Customer Support',
    url: 'https://iptvthefox.tv/contact', // Replace with your actual domain
  }
};

const websiteSchema: WebSite = {
  '@type': 'WebSite',
  name: 'IPTV THE FOX',
  url: 'https://iptvthefox.tv', // Replace with your actual domain
  potentialAction: {
    '@type': 'SearchAction',
    target: 'https://iptvthefox.tv/search?q={search_term_string}', // Replace with your actual domain and search path
    'query-input': 'required name=search_term_string',
  },
};


export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <HelmetProvider>
        <Helmet>
          <title>IPTV THE FOX - Premium IPTV Service & Free IPTV Trial</title>
          <meta name="description" content="Experience the best IPTV service with IPTV THE FOX. Get your free IPTV trial and access thousands of channels, movies, and series. Premium IPTV for USA and worldwide." />
          <meta name="keywords" content="iptv the fox, iptv, iptv service, iptv usa, iptv trial, iptv fox, fox iptv, the fox iptv, free trial iptv" />
          <meta name="author" content="IPTV THE FOX" />
          <meta name="creator" content="IPTV THE FOX" />
          <meta name="publisher" content="IPTV THE FOX" />
          
          <script type="application/ld+json">
            {JSON.stringify(organizationSchema)}
          </script>
          <script type="application/ld+json">
            {JSON.stringify(websiteSchema)}
          </script>
        </Helmet>
        <head>
          <link rel="preconnect" href="https://fonts.googleapis.com" />
          <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
          <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />
        </head>
        <body className={cn('font-body antialiased min-h-screen flex flex-col')}>
          <Header />
          <main className="flex-grow overflow-hidden">{children}</main>
          <Footer />
          <Toaster />
        </body>
      </HelmetProvider>
    </html>
  );
}
