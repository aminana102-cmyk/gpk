
import type { Metadata } from 'next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, FileText, AtSign, User, Share2, Database, Lock, Pencil, Info } from 'lucide-react';
import { FadeIn } from '@/components/fade-in';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Privacy Policy',
  description: 'Learn how IPTV THE FOX collects, uses, and protects your personal information. Our commitment to your privacy is paramount.',
};

const policySections = [
    {
        icon: Info,
        title: 'Introduction',
        content: "Welcome to IPTV THE FOX. We are committed to protecting your privacy and handling your data in an open and transparent manner. This privacy policy sets out how we collect, use, store, and protect your personal information when you use our IPTV services. By using our services, you agree to the collection and use of information in accordance with this policy.",
    },
    {
        icon: User,
        title: 'Information We Collect',
        content: "To provide and improve our service, we may collect the following information: a) Personal Identification Information: Name and email address when you register for a free trial or subscription. b) Service Configuration Data: Information about your device type, preferred IPTV player, and country to optimize your streaming experience. c) Usage Data: We may collect information on how the service is accessed and used (e.g., popular VOD categories), but we do not monitor what specific content you watch.",
    },
    {
        icon: Database,
        title: 'How We Use Your Information',
        content: "The information we collect is used for the following purposes: a) To provide and maintain our service, including activating your subscription and delivering content. b) To provide customer support and respond to your inquiries. c) To improve our service by understanding how users interact with our platform. d) To communicate with you about your subscription, service updates, or promotional offers, which you can opt-out of at any time.",
    },
    {
        icon: Share2,
        title: 'Information Sharing and Disclosure',
        content: "We do not sell, trade, or rent your personal identification information to others. Your privacy is our priority. We may share generic aggregated demographic information not linked to any personal identification information with our business partners for analysis and service improvement purposes. We will not disclose your personal data to any third party without your consent, except as required by law.",
    },
    {
        icon: Lock,
        title: 'Data Security',
        content: "We adopt appropriate data collection, storage, and processing practices and security measures to protect against unauthorized access, alteration, disclosure, or destruction of your personal information. However, no method of transmission over the Internet or method of electronic storage is 100% secure, and we cannot guarantee its absolute security.",
    },
    {
        icon: FileText,
        title: 'Your Rights and Choices',
        content: "You have the right to access, update, or request deletion of your personal information. If you wish to exercise any of these rights, please contact us. Please note that we may need to retain certain information for record-keeping purposes or to complete transactions that you began prior to your request.",
    },
    {
        icon: Pencil,
        title: 'Changes to This Privacy Policy',
        content: "IPTV THE FOX has the discretion to update this privacy policy at any time. When we do, we will revise the updated date at the bottom of this page. We encourage you to frequently check this page for any changes to stay informed about how we are helping to protect the personal information we collect.",
    },
];

export default function PrivacyPage() {
  return (
    <div className="container mx-auto px-6 py-12 md:py-16">
      <FadeIn>
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-extrabold font-headline text-primary">
            Privacy Policy
          </h1>
          <p className="mt-4 text-lg text-foreground/80">
            Your privacy is important to us. Here's how we collect, use, and protect your information.
          </p>
        </div>
      </FadeIn>

      <FadeIn delay={200}>
        <div className="mt-12 max-w-4xl mx-auto space-y-8">
            {policySections.map((section, index) => (
                <Card key={index} className="bg-card/50 border-border/80 transition-shadow duration-300 hover:shadow-lg">
                    <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <section.icon className="h-7 w-7 text-primary" />
                        <span className="text-2xl font-headline">{section.title}</span>
                    </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-foreground/90 text-base leading-relaxed">{section.content}</p>
                    </CardContent>
                </Card>
            ))}
             <Card className="bg-card/50 border-border/80 transition-shadow duration-300 hover:shadow-lg">
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <AtSign className="h-7 w-7 text-primary" />
                        <span className="text-2xl font-headline">Contact Us</span>
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-foreground/90 text-base leading-relaxed">
                        If you have any questions about this Privacy Policy, the practices of this site, or your dealings with this site, please <Link href="/contact" className="text-primary hover:underline">contact us</Link>.
                    </p>
                     <p className='text-sm text-muted-foreground mt-4'>This policy was last updated on {new Date().toLocaleDateString()}.</p>
                </CardContent>
            </Card>
        </div>
      </FadeIn>
    </div>
  );
}
