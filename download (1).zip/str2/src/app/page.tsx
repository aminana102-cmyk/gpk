import { HeroSection } from '@/components/sections/hero-section';
import { LogosSliderSection } from '@/components/sections/logos-slider-section';
import { FeaturesSection } from '@/components/sections/features-section';
import { WhyUsSection } from '@/components/sections/why-us-section';
import { PricingSummarySection } from '@/components/sections/pricing-summary-section';
import { TestimonialsSection } from '@/components/sections/testimonials-section';
import { DevicesSection } from '@/components/sections/devices-section';
import { FadeIn } from '@/components/fade-in';
import { MoviesSliderSection } from '@/components/sections/movies-slider-section';
import { HowItWorksSection } from '@/components/sections/how-it-works-section';
import { FaqSection } from '@/components/sections/faq-section';

export default function Home() {
  return (
    <div className="flex flex-col items-center">
      <HeroSection />
      <MoviesSliderSection />
      <LogosSliderSection />
      <FadeIn className="w-full">
        <PricingSummarySection />
      </FadeIn>
      <FadeIn className="w-full">
        <FeaturesSection />
      </FadeIn>
      <FadeIn className="w-full">
        <WhyUsSection />
      </FadeIn>
      <FadeIn className="w-full">
        <TestimonialsSection />
      </FadeIn>
      <FadeIn className="w-full">
        <HowItWorksSection />
      </FadeIn>
      <FadeIn className="w-full">
        <DevicesSection />
      </FadeIn>
      <FadeIn className="w-full">
        <FaqSection />
      </FadeIn>
    </div>
  );
}
