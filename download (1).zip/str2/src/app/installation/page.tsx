
import type { Metadata } from 'next';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FadeIn } from '@/components/fade-in';
import { AmazonFirestickGuide } from '@/components/installation-guides/amazon-firestick-guide';
import { SmartTvGuide } from '@/components/installation-guides/smart-tv-guide';
import { AndroidGuide } from '@/components/installation-guides/android-guide';
import type { ComponentType } from 'react';
import { IosGuide } from '@/components/installation-guides/ios-guide';
import { AppleTvGuide } from '@/components/installation-guides/apple-tv-guide';
import { RokuGuide } from '@/components/installation-guides/roku-guide';
import { WindowsGuide } from '@/components/installation-guides/windows-guide';

export const metadata: Metadata = {
  title: 'Setup Guide',
  description: 'Easy step-by-step guides to install and set up IPTV THE FOX on your favorite devices, including Smart TV, Amazon Firestick, Android Box, and more.',
};

interface Guide {
  device: string;
  component: ComponentType;
}

const installationGuides: Guide[] = [
  {
    device: 'Amazon Firestick',
    component: AmazonFirestickGuide,
  },
  {
    device: 'Smart TV (Samsung/LG)',
    component: SmartTvGuide,
  },
  {
    device: 'Android Box / Phone',
    component: AndroidGuide,
  },
  {
    device: 'iOS (iPhone/iPad)',
    component: IosGuide,
  },
  {
    device: 'Apple TV',
    component: AppleTvGuide,
  },
  {
    device: 'Windows',
    component: WindowsGuide,
  },
  {
    device: 'Roku',
    component: RokuGuide,
  },
];

export default function InstallationPage() {
  return (
    <div className="container mx-auto px-6 py-12 md:py-16">
      <FadeIn>
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-extrabold font-headline text-primary">
            Easy Installation &amp; Setup
          </h1>
          <p className="mt-4 text-lg text-foreground/80">
            Get started in minutes. Follow our simple, step-by-step guides to install IPTV THE FOX on your favorite device.
          </p>
        </div>
      </FadeIn>

      <FadeIn delay={200}>
        <div className="mt-12">
          <Tabs defaultValue={installationGuides[0].device} className="w-full">
            <TabsList className="h-auto flex-wrap justify-center">
              {installationGuides.map((guide) => (
                <TabsTrigger key={guide.device} value={guide.device}>
                  {guide.device}
                </TabsTrigger>
              ))}
            </TabsList>
            {installationGuides.map((guide) => (
              <TabsContent key={guide.device} value={guide.device}>
                <guide.component />
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </FadeIn>
    </div>
  );
}
