'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { Card, CardHeader, CardTitle, CardContent, CardFooter, CardDescription } from '@/components/ui/card';
import { CtaButton } from '@/components/cta-button';
import { Check, Star, X } from 'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { FadeIn } from '@/components/fade-in';
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { cn } from '@/lib/utils';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';

const fullFeatureList = [
    '4K Quality',
    'FHD / HD Quality',
    'More +41,000 Channels',
    '+130,000 VOD TV & Movies',
    'No Freezing Fast & Stable',
    'Premium Quality Server',
    'Supported all Devices',
    'Money-Back Guarantee',
    'Available Worldwide',
    'EPG & catch-up',
    '%99.99 Uptime',
    'Exclusive Sports Channels',
    'Priority 24/7 Support',
];

const pricingData = {
  basic: {
    features: [
      'More +20,000 Channels',
      '+80,000 VOD TV & Movies',
      'FHD / HD Quality',
      'No Freezing Fast & Stable',
      'Premium Quality Server',
      'Supported all Devices',
      'Money-Back Guarantee',
      'Available Worldwide',
      'EPG & catch-up',
      '%99.99 Uptime',
      'Exclusive Sports Channels',
      'Priority 24/7 Support',
    ],
    plans: [
      { name: '1 Month', durationMonths: 1, basePrice: 7, originalMonthlyPrice: 10 },
      { name: '3 Months', durationMonths: 3, basePrice: 16, originalMonthlyPrice: 10 },
      { name: '6 Months', durationMonths: 6, basePrice: 28, originalMonthlyPrice: 10 },
      { name: '1 Year', durationMonths: 12, basePrice: 45, originalMonthlyPrice: 10 },
    ],
  },
  pro: {
    features: [
      'More +41,000 Channels',
      '+130,000 VOD TV & Movies',
      '4K Quality',
      'FHD / HD Quality',
      'No Freezing Fast & Stable',
      'Premium Quality Server',
      'Supported all Devices',
      'Money-Back Guarantee',
      'Available Worldwide',
      'EPG & catch-up',
      '%99.99 Uptime',
      'Exclusive Sports Channels',
      'Priority 24/7 Support',
    ],
    plans: [
      { name: '1 Month', durationMonths: 1, basePrice: 14, originalMonthlyPrice: 15 },
      { name: '3 Months', durationMonths: 3, basePrice: 26, originalMonthlyPrice: 15 },
      { name: '6 Months', durationMonths: 6, basePrice: 45, isPopular: true, originalMonthlyPrice: 15 },
      { name: '1 Year', durationMonths: 12, basePrice: 72, originalMonthlyPrice: 15 },
    ],
  },
};

const faqs = [
  {
    question: 'What payment methods do you accept?',
    answer: 'We accept a variety of payment methods, including major credit cards (Visa, MasterCard) and cryptocurrencies. Please contact us for specific crypto payment details.',
  },
  {
    question: 'Is there a free trial available?',
    answer: 'Yes, we offer a free trial so you can test our service before committing. Please contact us on Telegram to request your free trial.',
  },
  {
    question: 'How quickly will my subscription be activated?',
    answer: 'Your subscription is activated instantly upon successful payment. You will receive an email with your login credentials and setup instructions immediately.',
  },
  {
    question: 'Can I use my subscription on multiple devices?',
    answer: 'Yes, you can select up to 5 connections (devices) when choosing your plan. The price will adjust automatically based on your selection.',
  },
];


function PricingContent() {
  const searchParams = useSearchParams();
  const initialPlan = searchParams.get('plan') as 'basic' | 'pro' || 'pro';
  
  const [connections, setConnections] = useState(1);
  const [planType, setPlanType] = useState<'basic' | 'pro'>(initialPlan);

  useEffect(() => {
    const planFromUrl = searchParams.get('plan') as 'basic' | 'pro';
    if (planFromUrl && (planFromUrl === 'basic' || planFromUrl === 'pro')) {
      setPlanType(planFromUrl);
    }
  }, [searchParams]);

  const calculatePrice = (basePrice: number, numConnections: number) => {
    if (numConnections === 1) {
      return basePrice;
    }
    const discount = 0.20; // 20% discount
    const total = (basePrice * numConnections) * (1 - discount);
    return Math.round(total);
  };

  const selectedPlanData = pricingData[planType];
  const selectedPlanName = planType.charAt(0).toUpperCase() + planType.slice(1);

  return (
    <div className="container mx-auto px-6 py-12 md:py-16">
      <FadeIn>
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-extrabold font-headline text-primary">
            Choose Your Perfect Plan
          </h1>
          <p className="mt-4 text-lg text-foreground/80">
            Select the number of connections and choose the plan that's right for you. All plans include the same premium features.
          </p>
        </div>
      </FadeIn>
      
      <FadeIn delay={100}>
        <div className="mt-12 flex flex-col items-center gap-8">
            <Tabs value={planType} onValueChange={(value) => setPlanType(value as 'basic' | 'pro')}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="basic">Basic</TabsTrigger>
                <TabsTrigger value="pro">Pro</TabsTrigger>
              </TabsList>
            </Tabs>
            <Card className="p-6 bg-card/50 shadow-lg border-border/80 w-full max-w-md">
                <p className="text-center font-bold mb-4 text-primary text-lg">Number of Connections (Devices)</p>
                <RadioGroup
                    defaultValue="1"
                    onValueChange={(value) => setConnections(parseInt(value))}
                    className="flex flex-wrap justify-center gap-4 md:gap-6"
                >
                    {[1, 2, 3, 4, 5].map(num => (
                        <div key={num} className="flex items-center space-x-2">
                             <RadioGroupItem value={String(num)} id={`r${num}`} className="h-5 w-5"/>
                             <Label htmlFor={`r${num}`} className="text-lg font-semibold">{num}</Label>
                        </div>
                    ))}
                </RadioGroup>
            </Card>
        </div>
      </FadeIn>

      <FadeIn delay={200}>
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 items-stretch">
          {selectedPlanData.plans.map((plan) => {
            const finalPrice = calculatePrice(plan.basePrice, connections);
            const originalPrice = calculatePrice(plan.originalMonthlyPrice * plan.durationMonths, connections);
            const savedPercentage = originalPrice > finalPrice ? Math.round(((originalPrice - finalPrice) / originalPrice) * 100) : 0;
            const checkoutUrl = `/checkout?plan=${selectedPlanName}&duration=${encodeURIComponent(plan.name)}&price=${finalPrice}&connections=${connections}&originalPrice=${originalPrice}`;

            return (
             <Card 
                key={plan.name}
                className={cn(
                    "flex flex-col text-center border-border/80 transition-all duration-300 hover:shadow-2xl hover:-translate-y-1 relative overflow-hidden",
                    plan.isPopular && "border-2 border-orange-500 shadow-xl"
                )}
             >
              {plan.isPopular && (
                 <div className="bg-orange-500 text-white font-bold py-1.5 text-sm flex items-center justify-center gap-2 absolute top-0 left-1/2 -translate-x-1/2 w-3/4 rounded-b-lg">
                    <Star className="h-4 w-4" /> Most Popular
                </div>
              )}
               {savedPercentage > 0 && (
                <Badge variant="destructive" className="absolute top-2 right-2 text-sm">
                  Save {savedPercentage}%
                </Badge>
              )}
              <CardHeader className={cn("pt-10")}>
                <CardTitle className="text-2xl font-headline">{plan.name}</CardTitle>
                <CardDescription className="pt-2">
                    <div className="flex justify-center items-baseline gap-2">
                        {originalPrice > finalPrice && (
                            <span className="text-xl line-through text-muted-foreground">
                                ${originalPrice}
                            </span>
                        )}
                        <span className="text-4xl font-bold text-primary">${finalPrice}</span>
                    </div>
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                 <ul className="space-y-3 text-left">
                  {selectedPlanData.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-3">
                        <Check className="h-5 w-5 text-green-500 flex-shrink-0" /> 
                        <span className='text-sm text-foreground/80'>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <CtaButton 
                    href={checkoutUrl}
                    className="w-full"
                    variant={plan.isPopular ? 'primary' : 'secondary'}
                    target="_self"
                >
                  Get It Now
                </CtaButton>
              </CardFooter>
            </Card>
          )})}
        </div>
      </FadeIn>


      <FadeIn delay={300}>
        <div className="mt-24">
          <h2 className="text-3xl font-bold text-center font-headline text-primary mb-8">Feature Comparison</h2>
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[250px]">Feature</TableHead>
                  <TableHead className="text-center">Basic</TableHead>
                  <TableHead className="text-center">Pro</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {fullFeatureList.map((feature) => (
                  <TableRow key={feature}>
                    <TableCell className="font-medium">{feature}</TableCell>
                    <TableCell className="text-center">
                        {pricingData.basic.features.includes(feature) || feature === 'FHD / HD Quality' ? (
                            <Check className="h-5 w-5 text-green-500 mx-auto" />
                        ) : (
                            <X className="h-5 w-5 text-red-500 mx-auto" />
                        )}
                    </TableCell>
                    <TableCell className="text-center">
                      {pricingData.pro.features.includes(feature) ? (
                         <Check className="h-5 w-5 text-green-500 mx-auto" />
                       ) : (
                         <X className="h-5 w-5 text-red-500 mx-auto" />
                       )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </div>
      </FadeIn>

      <FadeIn delay={400}>
        <div className="mt-24 max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-center font-headline text-primary mb-8">Frequently Asked Questions</h2>
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-lg font-semibold">{faq.question}</AccordionTrigger>
                <AccordionContent className="text-base text-foreground/80">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </FadeIn>
    </div>
  );
}

export default function PricingPage() {
    return (
        <Suspense fallback={<div>Loading plans...</div>}>
            <PricingContent />
        </Suspense>
    )
}
    
