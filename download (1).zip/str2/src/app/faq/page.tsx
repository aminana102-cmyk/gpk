'use client';

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { FadeIn } from '@/components/fade-in';

// Metadata cannot be exported from a client component directly.
// This will be addressed in a future update if SEO for this page is critical.
/*
import type { Metadata } from 'next';
export const metadata: Metadata = {
  title: 'Frequently Asked Questions',
  description: 'Find answers to common questions about IPTV THE FOX. Learn about payment methods, free trials, subscription activation, device compatibility, and more.',
};
*/

const faqData = [
  {
    slug: 'payment-methods',
    question: 'What payment methods do you accept?',
    answer: [
      'We aim to provide a flexible and secure payment process for all our customers. We accept a wide range of payment options to suit your needs.',
      'You can pay using major credit and debit cards, including Visa, MasterCard, and American Express. We also embrace the future of payments by accepting popular cryptocurrencies such as Bitcoin (BTC) and Ethereum (ETH).',
      'For specific instructions on how to pay with cryptocurrency or if you have questions about other payment methods, please do not hesitate to contact our support team on Telegram. They are available 24/7 to assist you.',
    ],
  },
  {
    slug: 'free-trial',
    question: 'Is there a free trial available?',
    answer: [
      'Yes, absolutely! We firmly believe in the quality of our service, and we want you to experience it firsthand before making a commitment. We offer a comprehensive 24-hour free trial that gives you full access to our entire platform.',
      'During the trial, you can explore our massive library of over 41,000 live channels, browse our extensive collection of 130,000+ VOD titles, and test the stability and quality of our streams on your own devices.',
      'To get your free trial, simply contact us on Telegram, and our team will set you up right away.',
    ],
  },
  {
    slug: 'activation-time',
    question: 'How quickly will my subscription be activated?',
    answer: [
      'We know you\'re excited to start watching, so we\'ve made our activation process instantaneous. As soon as your payment is successfully processed, our system automatically activates your subscription.',
      'You will immediately receive a confirmation email containing your login credentials (such as M3U link or Xtream Codes) and easy-to-follow, step-by-step instructions for setting up the service on your preferred device. You can go from payment to watching in just a few minutes!',
    ],
  },
  {
    slug: 'multiple-devices',
    question: 'Can I use my subscription on multiple devices?',
    answer: [
      'Our service is compatible with a wide range of devices, including Smart TVs, Amazon Firestick, Android Boxes, smartphones, tablets, and computers. You can install and log into your account on as many devices as you like.',
      'However, the ability to stream on multiple devices simultaneously depends on the number of "connections" included in your plan. Our standard subscription includes one connection, which means you can watch on one device at a time.',
      'If you need to watch on multiple screens at once (for example, for different family members), you can easily add more connections during the checkout process on our pricing page. We offer plans with up to 5 simultaneous connections at a discounted rate.',
    ],
  },
];

export default function FAQPage() {
  return (
    <div className="container mx-auto px-6 py-12 md:py-16">
      <FadeIn>
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-extrabold font-headline text-primary">
            Frequently Asked Questions
          </h1>
          <p className="mt-4 text-lg text-foreground/80">
            Everything you need to know about IPTV THE FOX. If your question isn't answered here, please contact us.
          </p>
        </div>
      </FadeIn>

      <FadeIn delay={200}>
        <div className="mt-12 max-w-4xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqData.map((faq, index) => (
              <AccordionItem key={faq.slug} value={`item-${index}`} id={faq.slug} className="scroll-mt-20">
                <AccordionTrigger className="text-2xl font-headline text-primary text-left">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="space-y-4 text-foreground/90 pt-2 text-base">
                  {faq.answer.map((paragraph, pIndex) => (
                    <p key={pIndex}>{paragraph}</p>
                  ))}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </FadeIn>
    </div>
  );
}
