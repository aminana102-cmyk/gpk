
import type { Metadata } from 'next';
import { ChannelList } from '@/components/channel-list';
import { FadeIn } from '@/components/fade-in';

export const metadata: Metadata = {
  title: 'Channel List',
  description: 'Explore our vast selection of over 41,000 channels from around the world. Search and filter by category to find your favorite sports, movies, news, and international content on IPTV THE FOX.',
};

export default function ChannelsPage() {
  return (
    <div className="container mx-auto px-6 py-12 md:py-16">
      <FadeIn>
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-extrabold font-headline text-primary">
            Explore Our Channel Universe
          </h1>
          <p className="mt-4 text-lg text-foreground/80">
            We offer more than 41,000 channels from every corner of the globe. What's listed below is just a glimpse of our most popular countries and platforms. Use the search to find what you're looking for!
          </p>
        </div>
      </FadeIn>
      <FadeIn delay={200}>
        <div className="mt-12">
          <ChannelList />
        </div>
      </FadeIn>
    </div>
  );
}
