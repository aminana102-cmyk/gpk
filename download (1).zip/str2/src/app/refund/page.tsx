
import type { Metadata } from 'next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BadgeDollarSign, Ban, Clock, MessageSquare, ListChecks, HelpCircle, AtSign, ShieldAlert } from 'lucide-react';
import { FadeIn } from '@/components/fade-in';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Refund Policy',
  description: 'Understand the refund policy for IPTV THE FOX. Learn about eligibility, the process for requesting a refund, and our money-back guarantee.',
};

const refundPolicySections = [
    {
        icon: ListChecks,
        title: 'Refund Eligibility by Plan',
        content: `Your satisfaction is our priority. We offer a conditional money-back guarantee. Eligibility for a refund depends on the subscription plan you have purchased and whether you have used a free trial. Please read the following terms carefully.`,
        details: [
            {
                subtitle: '1 Month Plan',
                points: [
                    'You are eligible for a refund within **1 day** of your purchase, **only if you have not used our free trial**.',
                    'If you have used a free trial, you are not eligible for a refund on the 1-month plan, as the trial is intended to allow you to test our service quality.'
                ]
            },
            {
                subtitle: '3 Month Plan',
                points: [
                    'You are eligible for a refund within **3 days** of your purchase.',
                    'If a refund is issued, the cost equivalent to **one month** of service will be deducted from the refund amount.'
                ]
            },
            {
                subtitle: '6 Month & 1 Year Plans',
                points: [
                    'You are eligible for a refund within **7 days** of your purchase.',
                    'If a refund is issued, the cost equivalent to **one month** of service will be deducted from the refund amount.'
                ]
            }
        ]
    },
    {
        icon: ShieldAlert,
        title: 'Early Cancellation Policy',
        content: 'For our longer-term plans, we offer the flexibility of early cancellation after the initial refund period has passed, subject to the following conditions:',
        details: [
            {
                subtitle: 'For 6-Month and 1-Year Plans',
                points: [
                    'You may request to cancel your subscription at any time.',
                    'Your refund will be the total amount paid, minus the cost for the months you have used the service, plus an additional **one-month cancellation fee**.',
                    'Example: If you have a 6-month plan and cancel after 2 months, you will be charged for 3 months (2 months of use + 1 month fee), and the remaining balance for 3 months will be refunded.'
                ]
            }
        ]
    },
    {
        icon: Ban,
        title: 'Non-Refundable Situations',
        content: "Refunds will not be issued under the following circumstances: a) The refund request is made after the specified refund period for your plan has expired. b) You have violated our Terms of Use. c) Technical issues originating from your end, such as poor internet connection, device incompatibility, or incorrect setup. We strongly encourage using our free trial to ensure compatibility.",
    },
    {
        icon: MessageSquare,
        title: 'How to Request a Refund',
        content: "To request a refund, you must contact our customer support team via Telegram or WhatsApp. Please provide your subscription details and the reason for your request. Our team will review your request and process the refund if it meets our policy criteria.",
    },
    {
        icon: Clock,
        title: 'Refund Processing Time',
        content: "Once your refund request is approved, we will process it within 3-5 business days. The time it takes for the funds to appear in your account may vary depending on your payment method and financial institution.",
    },
    {
        icon: HelpCircle,
        title: 'Technical Support First',
        content: "Before requesting a refund due to technical issues, we kindly ask that you contact our 24/7 support team. Our experts are always available to help you resolve any problems and ensure you have the best possible streaming experience.",
    },
];

export default function RefundPolicyPage() {
  return (
    <div className="container mx-auto px-6 py-12 md:py-16">
      <FadeIn>
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-extrabold font-headline text-primary">
            Refund Policy
          </h1>
          <p className="mt-4 text-lg text-foreground/80">
            We are committed to customer satisfaction. Here are the details of our money-back guarantee.
          </p>
        </div>
      </FadeIn>

      <FadeIn delay={200}>
        <div className="mt-12 max-w-4xl mx-auto space-y-8">
            {refundPolicySections.map((section, index) => (
                <Card key={index} className="bg-card/50 border-border/80 transition-shadow duration-300 hover:shadow-lg">
                    <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <section.icon className="h-7 w-7 text-primary" />
                        <span className="text-2xl font-headline">{section.title}</span>
                    </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-foreground/90 text-base leading-relaxed mb-4" dangerouslySetInnerHTML={{ __html: section.content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
                        {section.details && (
                          <div className="space-y-4 ml-2">
                            {section.details.map((detail, dIndex) => (
                              <div key={dIndex} className="p-4 rounded-lg bg-background/50">
                                <h4 className="font-semibold text-primary mb-2">{detail.subtitle}</h4>
                                <ul className="list-disc list-inside space-y-2 text-foreground/80">
                                  {detail.points.map((point, pIndex) => (
                                    <li key={pIndex} dangerouslySetInnerHTML={{ __html: point.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
                                  ))}
                                </ul>
                              </div>
                            ))}
                          </div>
                        )}
                    </CardContent>
                </Card>
            ))}
             <Card className="bg-card/50 border-border/80 transition-shadow duration-300 hover:shadow-lg">
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <AtSign className="h-7 w-7 text-primary" />
                        <span className="text-2xl font-headline">Contact Us</span>
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-foreground/90 text-base leading-relaxed">
                        If you have any questions about our Refund Policy, please <Link href="/contact" className="text-primary hover:underline">contact us</Link>.
                    </p>
                     <p className='text-sm text-muted-foreground mt-4'>This policy was last updated on {new Date().toLocaleDateString()}.</p>
                </CardContent>
            </Card>
        </div>
      </FadeIn>
    </div>
  );
}
