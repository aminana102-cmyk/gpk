
import type { Metadata } from 'next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, Tv, UserCheck, CreditCard, Copyright, Scale, Pencil, AtSign, ShieldBan } from 'lucide-react';
import { FadeIn } from '@/components/fade-in';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Terms of Use',
  description: 'Read the Terms of Use for IPTV THE FOX. Understand your rights and responsibilities when using our IPTV service.',
};

const termsSections = [
    {
        icon: FileText,
        title: 'Acceptance of Terms',
        content: "By accessing or using the IPTV THE FOX service, you agree to be bound by these Terms of Use and our Privacy Policy. If you do not agree to these terms, please do not use our services. These terms apply to all visitors, users, and others who access the service.",
    },
    {
        icon: Tv,
        title: 'Service Description',
        content: "IPTV THE FOX provides a premium IPTV subscription service that gives users access to live television channels and on-demand content. The service is provided 'as is' and we do not guarantee that it will always be available, uninterrupted, or error-free. We reserve the right to modify or discontinue the service at any time without notice.",
    },
    {
        icon: UserCheck,
        title: 'User Responsibilities',
        content: "You are responsible for your use of the service and for any consequences thereof. You agree to use the service only for lawful purposes and in a way that does not infringe the rights of, restrict, or inhibit anyone else's use and enjoyment of the service. You are responsible for maintaining the confidentiality of your account credentials.",
    },
    {
        icon: CreditCard,
        title: 'Subscriptions and Payments',
        content: "All subscriptions are billed according to the plan you select. Payments are processed securely. Subscriptions are for a fixed term and are not automatically renewed. To continue service after your term expires, you must purchase a new subscription. We offer a money-back guarantee under specific conditions outlined by our support team.",
    },
    {
        icon: Copyright,
        title: 'Copyright and Content',
        content: "The content provided through our service, including all channels and VOD, is for your personal and non-commercial use only. You may not re-stream, broadcast, distribute, or sell any of the content. All content is the property of the respective content owners and is protected by copyright laws.",
    },
    {
        icon: ShieldBan,
        title: 'Content Policy',
        content: "IPTV THE FOX is a family-friendly service. We do not offer, provide, or tolerate any form of adult, explicit, or otherwise sensitive content. Our channel and VOD library is curated to exclude such materials. Any attempt to use our service to access or distribute prohibited content will result in immediate termination of your account without a refund.",
    },
    {
        icon: Scale,
        title: 'Limitation of Liability',
        content: "IPTV THE FOX will not be liable for any direct, indirect, incidental, special, consequential, or exemplary damages, including but not limited to, damages for loss of profits, goodwill, use, data, or other intangible losses resulting from the use of or inability to use the service.",
    },
    {
        icon: Pencil,
        title: 'Changes to Terms',
        content: "We reserve the right, at our sole discretion, to modify or replace these Terms at any time. We will provide notice of any changes by posting the new Terms of Use on this page. Your continued use of the service after any such changes constitutes your acceptance of the new Terms.",
    },
];

export default function TermsPage() {
  return (
    <div className="container mx-auto px-6 py-12 md:py-16">
      <FadeIn>
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-extrabold font-headline text-primary">
            Terms of Use
          </h1>
          <p className="mt-4 text-lg text-foreground/80">
            Please read these terms carefully before using our service.
          </p>
        </div>
      </FadeIn>

      <FadeIn delay={200}>
        <div className="mt-12 max-w-4xl mx-auto space-y-8">
            {termsSections.map((section, index) => (
                <Card key={index} className="bg-card/50 border-border/80 transition-shadow duration-300 hover:shadow-lg">
                    <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <section.icon className="h-7 w-7 text-primary" />
                        <span className="text-2xl font-headline">{section.title}</span>
                    </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-foreground/90 text-base leading-relaxed">{section.content}</p>
                    </CardContent>
                </Card>
            ))}
             <Card className="bg-card/50 border-border/80 transition-shadow duration-300 hover:shadow-lg">
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <AtSign className="h-7 w-7 text-primary" />
                        <span className="text-2xl font-headline">Contact Information</span>
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-foreground/90 text-base leading-relaxed">
                        If you have any questions about these Terms of Use, please <Link href="/contact" className="text-primary hover:underline">contact us</Link>.
                    </p>
                     <p className='text-sm text-muted-foreground mt-4'>These terms were last updated on {new Date().toLocaleDateString()}.</p>
                </CardContent>
            </Card>
        </div>
      </FadeIn>
    </div>
  );
}
