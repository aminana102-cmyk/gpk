
import type { Metadata } from 'next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Target, Gem, HeartHandshake, Tv, Eye } from 'lucide-react';
import { FadeIn } from '@/components/fade-in';
import { CtaButton } from '@/components/cta-button';

export const metadata: Metadata = {
  title: 'About Us',
  description: 'Learn about the story and mission of IPTV THE FOX. Discover our commitment to providing the highest quality IPTV service with unparalleled support and stability.',
};

const aboutSections = [
    {
        icon: Target,
        title: 'Our Mission',
        content: "Our mission is simple: to provide a premium, reliable, and affordable IPTV service that brings the world of entertainment to your screen. We believe that everyone deserves access to high-quality content without the high costs and limitations of traditional cable.",
    },
    {
        icon: Eye,
        title: 'Our Vision',
        content: "We envision a future where entertainment is seamless and accessible to everyone, everywhere. IPTV THE FOX aims to be at the forefront of this revolution, continuously innovating and expanding our offerings to meet the evolving needs of our global audience.",
    },
    {
        icon: Gem,
        title: 'What We Offer',
        content: "We provide a comprehensive entertainment package with over 41,000 live channels and 130,000+ on-demand movies and series. From live sports and blockbuster movies to international news and kids' shows, our service is your one-stop shop for everything you want to watch.",
    },
     {
        icon: HeartHandshake,
        title: 'Our Commitment to Quality',
        content: "Quality is the cornerstone of our service. We invest in the best server infrastructure to deliver a stable, buffer-free experience with 99.9% uptime. Our streams are available in stunning 4K, FHD, and HD quality, ensuring you get the best viewing experience possible.",
    },
];

export default function AboutPage() {
  return (
    <div className="container mx-auto px-6 py-12 md:py-16">
      <FadeIn>
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-extrabold font-headline text-primary">
            Welcome to IPTV THE FOX
          </h1>
          <p className="mt-4 text-lg text-foreground/80">
            Your ultimate destination for premium entertainment. Discover our story and what makes us the best choice for your streaming needs.
          </p>
        </div>
      </FadeIn>

        <FadeIn delay={200}>
            <div className="mt-12 max-w-3xl mx-auto text-center">
                 <div>
                    <h2 className="text-3xl font-bold font-headline text-primary mb-4">Who We Are</h2>
                    <p className="text-foreground/90 text-base leading-relaxed">
                        IPTV THE FOX was born from a passion for entertainment and a desire to break free from the constraints of traditional television. We are a team of dedicated professionals and streaming enthusiasts committed to building the most stable and user-friendly IPTV platform on the market. We understand what viewers want: variety, quality, and reliability. That’s exactly what we deliver.
                    </p>
                </div>
            </div>
        </FadeIn>

      <FadeIn delay={300}>
        <div className="mt-16 max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
            {aboutSections.map((section, index) => (
                <Card key={index} className="bg-card/50 border-border/80 transition-shadow duration-300 hover:shadow-lg">
                    <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <section.icon className="h-7 w-7 text-primary" />
                        <span className="text-2xl font-headline">{section.title}</span>
                    </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-foreground/90 text-base leading-relaxed">{section.content}</p>
                    </CardContent>
                </Card>
            ))}
        </div>
      </FadeIn>

      <FadeIn delay={400}>
        <div className="mt-16 text-center bg-card/30 p-8 rounded-lg">
            <h2 className="text-3xl font-bold font-headline text-primary">Join the Entertainment Revolution</h2>
            <p className="mt-4 text-lg max-w-2xl mx-auto text-foreground/80">
                Ready to experience the difference? Get your free trial and discover why thousands of customers trust IPTV THE FOX for their entertainment.
            </p>
            <div className="mt-6">
                <CtaButton href="/checkout?trial=true" target="_self">
                    Start Your Free Trial
                </CtaButton>
            </div>
        </div>
      </FadeIn>
    </div>
  );
}
