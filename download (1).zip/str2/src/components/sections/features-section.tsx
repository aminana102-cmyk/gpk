import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tv2, Clapperboard, Zap, Award, ShieldCheck, Clock } from 'lucide-react';

const features = [
  {
    icon: Tv2,
    title: '41,000+ IPTV Channels',
    description: 'Access a massive selection of live TV channels from around the world, covering sports, news, and entertainment with our IPTV service.',
  },
  {
    icon: Clapperboard,
    title: '130,000+ VOD Library',
    description: 'Binge-watch your favorite movies and series with our extensive on-demand library, updated daily for all IPTV THE FOX users.',
  },
  {
    icon: Zap,
    title: '4K/UHD/HD Quality',
    description: 'Experience stunning picture quality with our high-definition and ultra-high-definition IPTV streams.',
  },
  {
    icon: Award,
    title: 'Premium Channels',
    description: 'Unlock exclusive content with access to a wide range of premium sports and movie channels. The best of IPTV is here.',
  },
  {
    icon: ShieldCheck,
    title: 'Stable & Reliable IPTV',
    description: 'Our robust servers ensure anti-freeze technology and 99.9% uptime for uninterrupted entertainment. A truly stable IPTV service.',
  },
  {
    icon: Clock,
    title: 'Instant Activation',
    description: 'Get started in minutes. Your IPTV subscription is activated instantly after payment confirmation.',
  },
];

export function FeaturesSection() {
  return (
    <section className="w-full py-16 md:py-24 bg-card/30">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-headline text-primary">
            The Ultimate Entertainment Experience
          </h2>
          <p className="mt-4 text-lg text-foreground">
            Discover the features that make IPTV THE FOX the number one choice for your streaming needs. Our IPTV service is second to none.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="bg-card border-border/80 hover:border-primary/50 hover:bg-muted/50 transition-all duration-300">
              <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-2">
                <feature.icon className="h-10 w-10 text-primary" />
                <CardTitle>{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-foreground/80">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
