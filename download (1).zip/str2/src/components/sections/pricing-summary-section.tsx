'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardFooter, CardDescription } from '@/components/ui/card';
import { Check, Star } from 'lucide-react';
import { CtaButton } from '../cta-button';
import { cn } from '@/lib/utils';
import { useState } from 'react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useRouter } from 'next/navigation';
import { Badge } from '../ui/badge';
import { Helmet, HelmetProvider } from 'react-helmet-async';
import { Product, Offer, MerchantReturnPolicy } from 'schema-dts';
import { formatISO } from 'date-fns';


const pricingData = {
  basic: {
    features: [
      '4K International Channels',
      'FHD & HD Local Channels',
      'More +20,000 Channels',
      '+80,000 VOD TV & Movies',
      'No Freezing Fast & Stable',
      'Premium Quality Server',
      'Supported all Devices',
      'Money-Back Guarantee',
      'Available Worldwide',
      'EPG & catch-up',
      '%99.99 Uptime',
      'Exclusive Sports Channels',
      'Priority 24/7 Support',
    ],
    plans: [
      { name: '1 Month', basePrice: 7, originalMonthlyPrice: 10, durationMonths: 1 },
      { name: '3 Months', basePrice: 16, originalMonthlyPrice: 10, durationMonths: 3 },
      { name: '6 Months', basePrice: 28, originalMonthlyPrice: 10, durationMonths: 6 },
      { name: '12 Months', basePrice: 45, originalMonthlyPrice: 10, durationMonths: 12 },
    ],
  },
  pro: {
    features: [
        'More +41,000 Channels',
        '+130,000 VOD TV & Movies',
        '4K / FHD / HD Quality',
        'No Freezing Fast & Stable',
        'Premium Quality Server',
        'Supported all Devices',
        'Money-Back Guarantee',
        'Available Worldwide',
        'EPG & catch-up',
        '%99.99 Uptime',
        'Exclusive Sports Channels',
        'Priority 24/7 Support',
    ],
    plans: [
        { name: '1 Month', basePrice: 14, originalMonthlyPrice: 15, durationMonths: 1 },
        { name: '3 Months', basePrice: 26, originalMonthlyPrice: 15, durationMonths: 3 },
        { name: '6 Months', basePrice: 45, isPopular: true, originalMonthlyPrice: 15, durationMonths: 6 },
        { name: '1 Year', basePrice: 72, originalMonthlyPrice: 15, durationMonths: 12 },
    ],
  },
};

const getReturnPolicy = (durationMonths: number): MerchantReturnPolicy => {
  let days = 1;
  if (durationMonths >= 6) {
    days = 7;
  } else if (durationMonths >= 3) {
    days = 3;
  }
  return {
    '@type': 'MerchantReturnPolicy',
    'applicableCountry': 'US',
    'returnPolicyCategory': 'MerchantReturnFiniteReturnPolicy',
    'merchantReturnDays': days,
    'returnMethod': 'ReturnByMail',
    'itemCondition': 'UsedItem'
  }
};


export function PricingSummarySection() {
    const [planType, setPlanType] = useState<'basic' | 'pro'>('pro');
    const router = useRouter();

    const selectedPlanData = pricingData[planType];
    const selectedPlanName = planType.charAt(0).toUpperCase() + planType.slice(1);

    const handlePlanChange = (value: string) => {
        router.push(`/pricing?plan=${value}`);
    };

     const generateProductSchema = (plan: typeof selectedPlanData.plans[0]): Product => {
        const fullPlanName = `IPTV THE FOX - ${selectedPlanName} Plan - ${plan.name}`;
        const returnPolicy = getReturnPolicy(plan.durationMonths);

        return {
            '@type': 'Product',
            'name': fullPlanName,
            'description': `Get access to ${selectedPlanData.features[0]} and ${selectedPlanData.features[1]} with our ${plan.name} ${selectedPlanName} plan. Enjoy instant activation and 24/7 support.`,
            'sku': `IPTV-FOX-${selectedPlanName.toUpperCase()}-${plan.durationMonths}M`,
            'image': 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/10938+(1).webp',
            'brand': {
                '@type': 'Brand',
                'name': 'IPTV THE FOX'
            },
            'offers': {
                '@type': 'Offer',
                'price': plan.basePrice.toString(),
                'priceCurrency': 'USD',
                'availability': 'https://schema.org/InStock',
                'url': `https://www.iptvthefox.tv/checkout?plan=${selectedPlanName}&duration=${encodeURIComponent(plan.name)}&price=${plan.basePrice}&connections=1`,
                'priceValidUntil': formatISO(new Date(new Date().setFullYear(new Date().getFullYear() + 1))),
                 'shippingDetails': {
                    '@type': 'OfferShippingDetails',
                    'shippingRate': {
                        '@type': 'MonetaryAmount',
                        'value': '0',
                        'currency': 'USD'
                    },
                    'deliveryTime': {
                        '@type': 'ShippingDeliveryTime',
                        'handlingTime': {
                            '@type': 'QuantitativeValue',
                            'minValue': 0,
                            'maxValue': 5,
                            'unitCode': 'MIN' 
                        },
                         'transitTime': {
                            '@type': 'QuantitativeValue',
                            'minValue': 0,
                            'maxValue': 1,
                            'unitCode': 'MIN'
                        }
                    }
                },
                'hasMerchantReturnPolicy': returnPolicy,
            },
             'deliveryLeadTime': {
                '@type': 'QuantitativeValue',
                'minValue': 0,
                'maxValue': 5,
                'unitCode': 'MIN',
                'description': 'Your IPTV subscription is delivered and activated instantly via email after payment confirmation.'
            },
            'hasOfferCatalog': {
                '@type': 'OfferCatalog',
                'name': `IPTV THE FOX ${selectedPlanName} Plans`,
                'numberOfItems': selectedPlanData.plans.length
            }
        };
    };

  return (
    <section className="w-full py-16 md:py-24 bg-card/30">
       <HelmetProvider>
            <Helmet>
                <script type="application/ld+json">
                    {JSON.stringify(selectedPlanData.plans.map(generateProductSchema))}
                </script>
            </Helmet>
        </HelmetProvider>
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-headline text-primary">
            Flexible Plans for Everyone
          </h2>
          <p className="mt-4 text-lg text-foreground">
            Choose the perfect plan that fits your entertainment needs. These plans are for a single connection.
          </p>
           <div className="mt-8 text-center">
             <p className="mt-2 text-sm text-muted-foreground mb-4">
                To see plans with more connections, please visit our full pricing page.
            </p>
            <Button asChild>
                <Link href="/pricing">
                    See All Plans &rarr;
                </Link>
            </Button>
        </div>
        </div>

        <div className="flex justify-center mb-8">
            <Tabs defaultValue="pro" onValueChange={handlePlanChange}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="basic">Basic</TabsTrigger>
                <TabsTrigger value="pro">Pro</TabsTrigger>
              </TabsList>
            </Tabs>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 items-stretch">
          {selectedPlanData.plans.map((plan) => {
            const originalPrice = plan.originalMonthlyPrice * plan.durationMonths;
            const checkoutUrl = `/checkout?plan=${selectedPlanName}&duration=${encodeURIComponent(plan.name)}&price=${plan.basePrice}&connections=1&originalPrice=${originalPrice}`;
            const savedPercentage = originalPrice > plan.basePrice ? Math.round(((originalPrice - plan.basePrice) / originalPrice) * 100) : 0;
            return (
            <Card 
                key={plan.name}
                className={cn(
                    "flex flex-col text-center border-border/80 transition-all duration-300 hover:shadow-2xl hover:-translate-y-1 relative overflow-hidden",
                    plan.isPopular && "border-2 border-orange-500 shadow-xl"
                )}
             >
              {plan.isPopular && (
                 <div className="bg-orange-500 text-white font-bold py-1.5 text-sm flex items-center justify-center gap-2 absolute top-0 left-1/2 -translate-x-1/2 w-3/4 rounded-b-lg">
                    <Star className="h-4 w-4" /> Most Popular
                </div>
              )}
              {savedPercentage > 0 && (
                <Badge variant="destructive" className="absolute top-2 right-2 text-sm">
                  Save {savedPercentage}%
                </Badge>
              )}
              <CardHeader className={cn("pt-10")}>
                <CardTitle className="text-2xl font-headline">{plan.name}</CardTitle>
                <CardDescription className="pt-2">
                    <div className="flex justify-center items-baseline gap-2">
                        {originalPrice > plan.basePrice && (
                            <span className="text-xl line-through text-muted-foreground">
                                ${originalPrice}
                            </span>
                        )}
                        <span className="text-4xl font-bold text-primary">${plan.basePrice}</span>
                    </div>
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                 <ul className="space-y-3 text-left">
                  {selectedPlanData.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-3">
                        <Check className="h-5 w-5 text-green-500 flex-shrink-0" /> 
                        <span className='text-sm text-foreground/80'>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                 <CtaButton 
                    href={checkoutUrl}
                    className="w-full"
                    variant={plan.isPopular ? 'primary' : 'secondary'}
                    target="_self"
                 >
                  Choose Plan
                </CtaButton>
              </CardFooter>
            </Card>
          )})}
        </div>
        
      </div>
    </section>
  );
}
