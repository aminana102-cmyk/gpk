
import Image from 'next/image';
import { CtaButton } from '@/components/cta-button';
import { CheckCircle } from 'lucide-react';

const FREE_TRIAL_CHECKOUT_URL = '/checkout?trial=true';

const benefits = [
  'Unmatched IPTV Streaming Quality',
  '99.9% Server Uptime Guarantee',
  '24/7 Expert Support for IPTV',
  'Instant & Easy Setup'
];

export function WhyUsSection() {
  return (
    <section className="w-full py-16 md:py-24 bg-background">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="relative aspect-square rounded-xl overflow-hidden shadow-2xl">
             <Image
                src="https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/77y77.webp"
                alt="High-performance IPTV streaming on a modern TV setup"
                data-ai-hint="modern living room"
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/70 to-transparent"></div>
          </div>
          <div>
            <h2 className="text-3xl md:text-4xl font-bold font-headline text-primary">
              The IPTV THE FOX Difference
            </h2>
            <p className="mt-4 text-lg text-foreground">
              We are not just another IPTV provider. We are committed to delivering a flawless, high-performance IPTV service backed by the best technology and dedicated support. Your entertainment is our priority at IPTV THE FOX.
            </p>
            <ul className="mt-6 space-y-3">
              {benefits.map((benefit, index) => (
                 <li key={index} className="flex items-center gap-3">
                    <CheckCircle className="h-6 w-6 text-green-500" />
                    <span className="text-lg text-foreground/80">{benefit}</span>
                </li>
              ))}
            </ul>
            <div className="mt-8">
              <CtaButton href={FREE_TRIAL_CHECKOUT_URL} target="_self">
                Start Your Free IPTV Trial
              </CtaButton>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
