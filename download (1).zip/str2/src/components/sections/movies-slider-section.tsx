'use client';

import { Card, CardContent } from '@/components/ui/card';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
} from '@/components/ui/carousel';
import Autoplay from "embla-carousel-autoplay";
import Image from 'next/image';

const movies = [
  {
    title: 'Mystery',
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/01.jpg',
    hint: 'mystery movie poster',
    category: 'Movie',
  },
  {
    title: 'Thriller',
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/02.jpg',
    hint: 'thriller movie poster',
    category: 'Movie',
  },
  {
    title: 'Animation',
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/03.jpg',
    hint: 'sci-fi movie poster',
    category: 'Movie',
  },
  {
    title: 'Horror comedy',
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/05.jpg',
    hint: 'horror comedy poster',
    category: 'Movie',
  },
  {
    title: 'action',
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/06.jpg',
    hint: 'drama movie poster',
    category: 'Movie',
  },
  {
    title: 'Drama',
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/07.jpg',
    hint: 'thriller movie poster',
    category: 'Movie',
  },
  {
    title: 'Historical',
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/12.jpg',
    hint: 'historical series poster',
    category: 'Series',
  },
  {
    title: 'UFC',
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/13.jpg',
    hint: 'UFC sport poster',
    category: 'Sport',
  },
  {
    title: 'basketball',
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/14.jpg',
    hint: 'basketball sport poster',
    category: 'Sport',
  },
  {
    title: 'football Usa',
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/15.jpg',
    hint: 'football sport poster',
    category: 'Sport',
  },
];

export function MoviesSliderSection() {
  return (
    <section className="w-full py-16 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-headline text-primary">
            Watch our favorite movies and TV shows <span className="text-accent">anytime</span>
          </h2>
          <p className="mt-4 text-lg text-foreground/80">
            Enjoy an unbeatable price for an unlimited selection of content.
          </p>
        </div>
        <Carousel
          opts={{
            align: 'start',
            loop: true,
          }}
          plugins={[
            Autoplay({
              delay: 2500,
              stopOnInteraction: false,
            }),
          ]}
          className="w-full"
        >
          <CarouselContent className="-ml-4">
            {movies.map((movie, index) => (
              <CarouselItem
                key={index}
                className="basis-1/2 sm:basis-1/3 md:basis-1/4 lg:basis-1/5 xl:basis-1/6 pl-4"
              >
                <div className="group relative overflow-hidden rounded-lg">
                  <Card className="border-none shadow-none">
                    <CardContent className="relative aspect-[2/3] p-0">
                       <Image
                        src={movie.src}
                        alt={movie.title}
                        width={400}
                        height={600}
                        className="object-cover w-full h-full transition-transform duration-300 group-hover:scale-110"
                        data-ai-hint={movie.hint}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
                    </CardContent>
                  </Card>
                   <div className="absolute bottom-4 left-4">
                    <h3 className="text-white font-bold text-lg">{movie.title}</h3>
                    <p className="text-red-500 text-sm font-semibold">{movie.category}</p>
                  </div>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
        </Carousel>
      </div>
    </section>
  );
}
