import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tv, Smartphone, Box, Monitor, Tablet } from 'lucide-react';

const devices = [
  { name: 'Smart TV', icon: Tv },
  { name: 'Amazon Firestick', icon: Monitor }, // Using monitor as a proxy
  { name: 'Android Box', icon: Box },
  { name: 'iOS Devices', icon: Smartphone },
  { name: 'Android Phones', icon: Smartphone },
  { name: 'Tablets', icon: Tablet },
  { name: 'PC/Laptop', icon: Monitor },
  { name: 'MAG Box / Enigma2', icon: Box },
];

export function DevicesSection() {
  return (
    <section className="w-full py-16 md:py-24 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-headline text-primary">
            Watch On Any Device
          </h2>
          <p className="mt-4 text-lg text-foreground">
            Our service is compatible with all your favorite devices. Enjoy a seamless viewing experience wherever you are.
          </p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4 gap-6">
          {devices.map((device, index) => (
            <Card key={index} className="bg-card text-center flex flex-col items-center justify-center p-6 border-border/80 hover:border-primary/50 hover:bg-muted/50 transition-all duration-300 transform hover:-translate-y-1">
              <device.icon className="h-12 w-12 text-primary mb-4" />
              <CardHeader className="p-0">
                <CardTitle className="text-base font-semibold">{device.name}</CardTitle>
              </CardHeader>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
