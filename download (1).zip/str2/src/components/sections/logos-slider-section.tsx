'use client';

import { Card, CardContent } from '@/components/ui/card';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
} from '@/components/ui/carousel';
import Autoplay from "embla-carousel-autoplay";
import Image from 'next/image';

const logos = [
  {
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/Small+cover/brand_item22-150x46-1-1.webp',
    alt: 'Channel Logo',
    hint: 'sports logo',
  },
  {
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/Small+cover/brand_item13-150x46-1-1.webp',
    alt: 'Channel Logo 2',
    hint: 'movie logo',
  },
  {
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/Small+cover/brand_item06-150x46-1-1.webp',
    alt: 'Channel Logo 3',
    hint: 'news logo',
  },
  {
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/Small+cover/brand_item08-150x46-1-1.webp',
    alt: 'Channel Logo 4',
    hint: 'entertainment logo',
  },
  {
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/Small+cover/brand_item18-150x46-1-1.webp',
    alt: 'Channel Logo 5',
    hint: 'music logo',
  },
  {
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/Small+cover/brand_item21-150x46-1-1.webp',
    alt: 'Channel Logo 6',
    hint: 'documentary logo',
  },
   {
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/Small+cover/IMG_20250923_191122_(150_x_46_pixel).png',
    alt: 'Channel Logo 7',
    hint: 'kids logo',
  },
   {
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/Small+cover/brand_item12-1.webp',
    alt: 'Channel Logo 8',
    hint: 'international logo',
  },
];

const logos2 = [
  {
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/Small+cover/brand_item15-150x46-1-1.webp',
    alt: 'Channel Logo 9',
    hint: 'sports logo',
  },
  {
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/Small+cover/brand_item14-150x46-1-1.webp',
    alt: 'Channel Logo 10',
    hint: 'movie logo',
  },
  {
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/Small+cover/brand_item16-150x46-1-1.webp',
    alt: 'Channel Logo 11',
    hint: 'news logo',
  },
  {
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/Small+cover/brand_item17-150x46-1-1.webp',
    alt: 'Channel Logo 12',
    hint: 'entertainment logo',
  },
  {
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/Small+cover/brand_item05-150x46-1-1.webp',
    alt: 'Channel Logo 13',
    hint: 'music logo',
  },
  {
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/Small+cover/IMG_20250923_192403_(150_x_65_pixel).png',
    alt: 'Channel Logo 14',
    hint: 'documentary logo',
  },
  {
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/Small+cover/IMG_20250923_191335_(150_x_46_pixel).png',
    alt: 'Channel Logo 15',
    hint: 'kids logo',
  },
   {
    src: 'https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/Small+cover/brand_item11-1.webp',
    alt: 'Channel Logo 16',
    hint: 'international logo',
  },
];

export function LogosSliderSection() {
  return (
    <section className="w-full py-16 md:py-24 bg-background/50">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-headline text-primary">
            The Global Content You Love, All in One Place
          </h2>
          <p className="mt-4 text-lg text-foreground/80">
            IPTV THE FOX brings you a world of entertainment. What you see here is just a sample of the thousands of prominent channels and platforms we proudly offer.
          </p>
        </div>
        <div className="space-y-4">
          <Carousel
            opts={{
              align: 'start',
              loop: true,
            }}
            plugins={[
              Autoplay({
                delay: 2000,
                stopOnInteraction: false,
              }),
            ]}
            className="w-full"
          >
            <CarouselContent>
              {logos.map((logo, index) => (
                <CarouselItem
                  key={index}
                  className="basis-1/4 sm:basis-1/6 md:basis-1/8 lg:basis-1/10"
                >
                  <div className="p-1">
                    <Card className="bg-transparent border-none shadow-none">
                      <CardContent className="flex aspect-video items-center justify-center p-2">
                        <Image
                          src={logo.src}
                          alt={logo.alt}
                          width={400}
                          height={200}
                          className="object-contain w-full h-auto opacity-60 hover:opacity-100 transition-all duration-300"
                          data-ai-hint={logo.hint}
                        />
                      </CardContent>
                    </Card>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
          </Carousel>
           <Carousel
            opts={{
              align: 'start',
              loop: true,
            }}
            plugins={[
              Autoplay({
                delay: 2000,
                stopOnInteraction: false,
                direction: 'backward',
              }),
            ]}
            className="w-full"
          >
            <CarouselContent>
              {logos2.map((logo, index) => (
                <CarouselItem
                  key={index}
                  className="basis-1/4 sm:basis-1/6 md:basis-1/8 lg:basis-1/10"
                >
                  <div className="p-1">
                    <Card className="bg-transparent border-none shadow-none">
                      <CardContent className="flex aspect-video items-center justify-center p-2">
                        <Image
                          src={logo.src}
                          alt={logo.alt}
                          width={400}
                          height={200}
                          className="object-contain w-full h-auto opacity-60 hover:opacity-100 transition-all duration-300"
                          data-ai-hint={logo.hint}
                        />
                      </CardContent>
                    </Card>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
          </Carousel>
        </div>
      </div>
    </section>
  );
}
