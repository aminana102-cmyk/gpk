'use client';

import { Card, CardContent } from '@/components/ui/card';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Star } from 'lucide-react';
import Autoplay from 'embla-carousel-autoplay';

const testimonials = [
  {
    name: 'John D.',
    avatar: 'JD',
    rating: 5,
    text: 'Absolutely the best IPTV service I have ever used. The quality is insane, and I have never experienced any buffering. Highly recommended!',
  },
  {
    name: 'Maria S.',
    avatar: 'MS',
    rating: 5,
    text: 'The channel list is massive, and the VOD library is always updated with the latest movies. My family loves it. The setup was super easy too.',
  },
  {
    name: 'Alex T.',
    avatar: 'AT',
    rating: 4.5,
    text: 'I was skeptical at first, but IPTV THE FOX exceeded all my expectations. Customer support is fantastic and helped me get started in minutes.',
  },
  {
    name: 'Samantha P.',
    avatar: 'SP',
    rating: 5,
    text: 'Flawless 4K streaming for sports. I never miss a game, and the picture quality is better than my old cable subscription. A total game-changer!',
  },
  {
    name: 'Michael B.',
    avatar: 'MB',
    rating: 4,
    text: 'Great service overall. Huge selection of channels. Sometimes a few of the international channels lag, but it\'s rare. Good value for the price.',
  },
  {
    name: 'Jessica L.',
    avatar: 'JL',
    rating: 5,
    text: 'As a movie lover, the VOD section is a dream come true. It has everything from classics to new releases. 10/10 would recommend.',
  },
  {
    name: 'David R.',
    avatar: 'DR',
    rating: 4.5,
    text: 'Very stable service. The EPG is clean and easy to navigate. The ability to use it on multiple devices is a huge plus for my family.',
  },
  {
    name: 'Emily C.',
    avatar: 'EC',
    rating: 5,
    text: 'I signed up for the free trial and was so impressed I subscribed for a full year on the same day. The support team is super friendly and responsive.',
  },
  {
    name: 'Chris G.',
    avatar: 'CG',
    rating: 5,
    text: 'Best way to watch international soccer. I get access to games I couldn\'t find anywhere else. The stream quality is consistently high.',
  },
  {
    name: 'Olivia M.',
    avatar: 'OM',
    rating: 4,
    text: 'The installation was a bit tricky on my older Smart TV, but their guide was helpful. Once set up, it works like a charm. Happy customer.',
  },
  {
    name: 'Daniel K.',
    avatar: 'DK',
    rating: 5,
    text: 'I\'ve tried several IPTV services, and The Fox is by far the most reliable. No freezing during big sports events, which is all I ask for!',
  },
  {
    name: 'Sophia A.',
    avatar: 'SA',
    rating: 4.5,
    text: 'The variety of kids\' channels is amazing. It keeps my children entertained for hours with safe and fun content. The parental controls are easy to use.',
  },
  {
    name: 'James W.',
    avatar: 'JW',
    rating: 5,
    text: 'Exceptional customer service. I had a question about my subscription and got a helpful reply on Telegram within minutes. Very professional.',
  },
  {
    name: 'Isabella N.',
    avatar: 'IN',
    rating: 4.5,
    text: 'The price is unbeatable for what you get. I\'m saving a fortune compared to my old cable bill, and I have way more content now.',
  },
  {
    name: 'Ethan H.',
    avatar: 'EH',
    rating: 5,
    text: 'Works perfectly on my Firestick. The app is fast and intuitive. I highly recommend it to anyone looking to cut the cord.',
  },
  {
    name: 'Mia Z.',
    avatar: 'MZ',
    rating: 4,
    text: 'A really solid service. The VOD library is huge, though I wish there was a better way to sort through it. But for the price, I can\'t complain.',
  },
  {
    name: 'Lucas F.',
    avatar: 'LF',
    rating: 5,
    text: 'I\'ve been a customer for over a year now and the service has only gotten better. The team is clearly dedicated to providing a quality product.',
  },
  {
    name: 'Ava J.',
    avatar: 'AJ',
    rating: 5,
    text: 'The instant activation is no joke. I paid and received my credentials in less than 5 minutes. The whole process was incredibly smooth.',
  },
  {
    name: 'Noah G.',
    avatar: 'NG',
    rating: 4.5,
    text: 'Great for news channels from around the world. I can keep up with current events from different perspectives. Very happy with the service.',
  },
  {
    name: 'Charlotte B.',
    avatar: 'CB',
    rating: 5,
    text: 'IPTV THE FOX is the real deal. Stable, high-quality, and a massive amount of content. I\'ve already recommended it to all my friends.',
  },
];

const StarRating = ({ rating }: { rating: number }) => {
  return (
    <div className="flex text-orange-500">
      {[...Array(5)].map((_, i) => {
        const ratingValue = i + 1;
        if (ratingValue <= rating) {
          return <Star key={i} className="h-5 w-5 fill-current" />;
        }
        if (ratingValue - 0.5 === rating) {
          return (
            <div key={i} className="relative">
              <Star key={`half-${i}`} className="h-5 w-5" />
              <div className="absolute top-0 left-0 w-1/2 h-full overflow-hidden">
                <Star key={`half-fill-${i}`} className="h-5 w-5 fill-current" />
              </div>
            </div>
          );
        }
        return <Star key={i} className="h-5 w-5" />;
      })}
    </div>
  );
};

export function TestimonialsSection() {
  return (
    <section className="w-full py-16 md:py-24 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-headline text-primary">
            What Our Customers Say
          </h2>
          <p className="mt-4 text-lg text-foreground">
            Trusted by thousands of users worldwide. Here's what they think about IPTV THE FOX.
          </p>
        </div>
        <Carousel
          opts={{
            align: 'start',
            loop: true,
          }}
          plugins={[
            Autoplay({
              delay: 3000,
              stopOnInteraction: false,
            }),
          ]}
          className="w-full max-w-4xl mx-auto"
        >
          <CarouselContent>
            {testimonials.map((testimonial, index) => (
              <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/3 flex">
                <div className="p-1 w-full">
                  <Card className="h-full flex flex-col justify-between">
                    <CardContent className="p-6 flex flex-col items-start gap-4">
                      <StarRating rating={testimonial.rating} />
                      <p className="text-foreground/80 italic">"{testimonial.text}"</p>
                      <div className="flex items-center gap-4 pt-4">
                        <Avatar>
                          <AvatarImage src={`https://placehold.co/40x40.png?text=${testimonial.avatar}`} />
                          <AvatarFallback>{testimonial.avatar}</AvatarFallback>
                        </Avatar>
                        <p className="font-bold text-primary">{testimonial.name}</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious />
          <CarouselNext />
        </Carousel>
      </div>
    </section>
  );
}
