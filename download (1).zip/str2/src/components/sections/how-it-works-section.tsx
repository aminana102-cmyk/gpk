import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tv, PlaySquare, ListVideo, SlidersHorizontal } from 'lucide-react';

const steps = [
  {
    icon: Tv,
    title: 'Stream Live TV & Events',
    description: 'With IPTV THE FOX, watch live TV and exclusive pay-per-view events. Access movies, shows, and live sports on devices like FireStick or Android TV via your favorite IPTV app.',
  },
  {
    icon: PlaySquare,
    title: 'Use Your Favorite IPTV Player',
    description: 'Our IPTV service is compatible with top IPTV players. Stream live TV and a huge library of on-demand content (VOD) seamlessly across multiple devices.',
  },
  {
    icon: ListVideo,
    title: 'Navigate with Electronic Program Guides (EPG)',
    description: 'IPTV THE FOX includes a user-friendly EPG to help you browse channels effortlessly. Request a free IPTV trial to test all our premium features before you subscribe.',
  },
  {
    icon: SlidersHorizontal,
    title: 'Enjoy Unmatched Flexibility',
    description: 'Whether you use an M3U playlist or Xtream Codes, our IPTV service adapts to your needs. From international channels to a vast VOD library, IPTV THE FOX works your way.',
  },
];

export function HowItWorksSection() {
  return (
    <section className="w-full py-16 md:py-24 bg-card/30">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-headline text-primary">
            How Our IPTV Service Works
          </h2>
          <p className="mt-4 text-lg text-foreground">
            Your simple guide to our IPTV service, including streaming, EPG, players, and multi-device viewing with The Fox IPTV.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {steps.map((step, index) => (
            <Card key={index} className="bg-card border-border/80 hover:border-primary/50 hover:bg-muted/50 transition-all duration-300">
              <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-2">
                <step.icon className="h-10 w-10 text-primary" />
                <CardTitle>{step.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-foreground/80">{step.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
