import Link from 'next/link';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';

const faqs = [
  {
    question: 'What payment methods do you accept?',
    answer: 'We accept a variety of payment methods for your convenience, including major credit cards (Visa, MasterCard, American Express) and cryptocurrencies like Bitcoin and Ethereum. Our goal is to make the payment process as smooth as possible.',
    slug: 'payment-methods'
  },
  {
    question: 'Is there a free trial available?',
    answer: 'Yes, absolutely! We offer a 24-hour free trial so you can test our service quality and channel lineup before committing. We are confident you will love the experience.',
    slug: 'free-trial'
  },
  {
    question: 'How quickly will my subscription be activated?',
    answer: 'Your subscription is activated instantly upon successful payment. You will receive an email with your login credentials and detailed setup instructions immediately, so you can start watching within minutes.',
    slug: 'activation-time'
  },
  {
    question: 'Can I use my subscription on multiple devices?',
    answer: 'Yes, you can use your subscription on multiple devices. However, simultaneous streaming depends on the number of connections you purchase. Our base plan allows one connection, but you can add up to 5 connections on our pricing page.',
    slug: 'multiple-devices'
  },
];

export function FaqSection() {
  return (
    <section className="w-full py-16 md:py-24 bg-card/30">
        <div className="container mx-auto px-6">
            <div className="max-w-3xl mx-auto">
              <div className="text-center mb-12">
                  <h2 className="text-3xl md:text-4xl font-bold font-headline text-primary">
                    Frequently Asked Questions
                  </h2>
                  <p className="mt-4 text-lg text-foreground">
                    Have questions? We've got answers. If you can't find what you're looking for, feel free to contact us.
                  </p>
              </div>
              <Accordion type="single" collapsible className="w-full">
                {faqs.map((faq, index) => (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger className="text-lg font-semibold text-left">{faq.question}</AccordionTrigger>
                    <AccordionContent className="text-base text-foreground/80 space-y-4">
                      <p>{faq.answer}</p>
                       <Button variant="link" asChild className="p-0 h-auto">
                        <Link href={`/faq#${faq.slug}`} className="text-primary">
                          Read More &rarr;
                        </Link>
                      </Button>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
        </div>
    </section>
  );
}
