'use client';

import { CtaButton } from '@/components/cta-button';
import { FadeIn } from '../fade-in';
import { MessageCircle, ArrowRight, Tv2, Globe, Zap, Film } from 'lucide-react';
import Image from 'next/image';

const FREE_TRIAL_CHECKOUT_URL = '/checkout?trial=true';

const features = [
  { icon: Tv2, text: '4K / FHD / HD Quality' },
  { icon: Globe, text: '+41,000 Channels' },
  { icon: Film, text: '+130,000 VOD' },
  { icon: Zap, text: '24/7 Support' },
];

export function HeroSection() {
  return (
    <section className="relative w-full h-auto min-h-[80vh] md:min-h-[90vh] flex items-center justify-center text-center overflow-hidden bg-background py-12 md:py-20">
      <div className="absolute inset-0 z-0">
        <Image
          src="https://firebasestorage.googleapis.com/v0/b/dracola-4f61b.appspot.com/o/thefox%2FSmall%20cover%2Fquality_restoration_20250924004733072.jpg?alt=media&token=2cc30ec5-335f-4d6b-b51f-5e40a9e36fff"
          alt="Abstract background representing digital streaming"
          data-ai-hint="abstract technology"
          fill
          className="object-cover opacity-50"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent"></div>
      </div>
      
      <div className="container relative z-10 px-6">
        <FadeIn>
          <h1 className="text-4xl md:text-6xl font-extrabold font-headline text-primary leading-tight tracking-tighter">
            IPTV THE FOX: Your #1 IPTV Service Provider
          </h1>
        </FadeIn>
        <FadeIn delay={200}>
          <p className="mt-6 max-w-3xl mx-auto text-lg md:text-xl text-foreground/80">
            Welcome to IPTV THE FOX, the leading IPTV service for USA and international viewers. Experience high-performance streaming, instant setup, and get your free IPTV trial today. The Fox IPTV is your gateway to unlimited entertainment.
          </p>
        </FadeIn>
        <FadeIn delay={400}>
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <CtaButton href={FREE_TRIAL_CHECKOUT_URL} variant="primary" className="flex items-center gap-2" target='_self'>
              <MessageCircle className="h-5 w-5" />
              Get Free IPTV Trial
            </CtaButton>
            <CtaButton href="/pricing" variant="secondary" className="flex items-center gap-2" target='_self'>
              View IPTV Plans
              <ArrowRight className="h-5 w-5" />
            </CtaButton>
          </div>
        </FadeIn>
         <FadeIn delay={600}>
          <div className="mt-12 flex flex-wrap items-center justify-center gap-x-6 gap-y-4 sm:gap-x-8">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center gap-3">
                <feature.icon className="h-6 w-6 text-primary" />
                <span className="text-base font-semibold text-foreground/90">{feature.text}</span>
              </div>
            ))}
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
