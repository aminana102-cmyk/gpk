
import Link from 'next/link';
import { Button } from '../ui/button';
import { MessageCircle, Phone } from 'lucide-react';
import Image from 'next/image';

const TELEGRAM_LINK = 'https://t.me/ZYNN_TV';
const WHATSAPP_LINK = 'https://wa.me/212629095943';

const mainLinks = [
  { href: '/', label: 'Home' },
  { href: '/pricing', label: 'Pricing' },
  { href: '/installation', label: 'Installation' },
  { href: '/channels', label: 'Channels' },
];

const legalLinks = [
  { href: '/about', label: 'About Us' },
  { href: '/faq', label: 'FAQ' },
  { href: '/contact', label: 'Contact' },
  { href: '/terms', label: 'Terms of Use' },
  { href: '/privacy', label: 'Privacy Policy' },
  { href: '/refund', label: 'Refund Policy' },
];


export function Footer() {
  return (
    <footer className="bg-card/50 border-t border-border/50">
      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-3 mb-4">
              <Image src="https://yons-alliptv.s3.us-east-1.amazonaws.com/New+foldeslider/10938+(1).webp" alt="IPTV THE FOX Logo" width={65} height={65} />
               <span className="text-xl font-bold font-headline text-primary">IPTV THE FOX</span>
            </Link>
             <p className="text-sm text-foreground/80 max-w-xs">
              Your gateway to unlimited entertainment. High-quality streaming for movies, series, and live TV.
            </p>
          </div>
          
          <div className="md:col-span-3 grid grid-cols-2 md:grid-cols-3 gap-8">
             <div>
              <h3 className="font-headline font-semibold text-card-foreground mb-4">Quick Links</h3>
              <ul className="space-y-2">
                {mainLinks.map((link) => (
                   <li key={link.href}>
                    <Link href={link.href} className="text-sm text-foreground hover:text-primary transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h3 className="font-headline font-semibold text-card-foreground mb-4">Support & Legal</h3>
              <ul className="space-y-2">
                {legalLinks.map((link) => (
                   <li key={link.href}>
                    <Link href={link.href} className="text-sm text-foreground hover:text-primary transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
                 <h3 className="font-headline font-semibold text-card-foreground mb-4">Contact Us</h3>
                 <div className="flex items-center space-x-4">
                    <Button variant="ghost" size="icon" asChild>
                      <a href={TELEGRAM_LINK} target="_blank" rel="noopener noreferrer" aria-label="Telegram">
                        <MessageCircle className="h-6 w-6" />
                      </a>
                    </Button>
                    <Button variant="ghost" size="icon" asChild>
                      <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" aria-label="WhatsApp">
                        <Phone className="h-6 w-6" />
                      </a>
                    </Button>
                  </div>
            </div>
          </div>

        </div>
        <div className="mt-12 pt-8 border-t border-border/50 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} IPTV THE FOX. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
}
