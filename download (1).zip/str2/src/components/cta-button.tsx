import { cn } from '@/lib/utils';
import Link from 'next/link';
import type { ReactNode } from 'react';

interface CtaButtonProps {
  href: string;
  children: ReactNode;
  variant?: 'primary' | 'secondary';
  className?: string;
  target?: string;
}

export function CtaButton({
  href,
  children,
  variant = 'primary',
  className,
  target = '_blank',
}: CtaButtonProps) {
  const baseClasses =
    'inline-flex items-center justify-center px-8 py-3 text-base font-bold rounded-md shadow-lg transition-transform transform hover:scale-105 duration-300 ease-in-out';

  const variantClasses = {
    primary: 'text-white bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700',
    secondary: 'text-primary border-2 border-orange-500 bg-transparent hover:bg-orange-500 hover:text-white',
  };

  return (
    <Link href={href} className={cn(baseClasses, variantClasses[variant], className)} target={target} rel="noopener noreferrer">
      {children}
    </Link>
  );
}
