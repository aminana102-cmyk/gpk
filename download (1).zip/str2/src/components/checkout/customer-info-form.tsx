"use client";

import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Globe, Tv, PlaySquare, Fingerprint, Server } from "lucide-react";
import { Input } from '../ui/input';
import { RadioGroup, RadioGroupItem } from '../ui/radio-group';

const countries = {
  "Africa": [
    "Algeria", "Angola", "Benin", "Botswana", "Burkina Faso", "Burundi", "Cabo Verde", "Cameroon", "Central African Republic",
    "Chad", "Comoros", "Congo, Democratic Republic of the", "Congo, Republic of the", "Cote d'Ivoire", "Djibouti", "Egypt",
    "Equatorial Guinea", "Eritrea", "Eswatini", "Ethiopia", "Gabon", "Gambia", "Ghana", "Guinea", "Guinea-Bissau", "Kenya",
    "Lesotho", "Liberia", "Libya", "Madagascar", "Malawi", "Mali", "Mauritania", "Mauritius", "Morocco", "Mozambique", "Namibia",
    "Niger", "Nigeria", "Rwanda", "Sao Tome and Principe", "Senegal", "Seychelles", "Sierra Leone", "Somalia", "South Africa",
    "South Sudan", "Sudan", "Tanzania", "Togo", "Tunisia", "Uganda", "Zambia", "Zimbabwe"
  ],
  "Americas": [
    "Antigua and Barbuda", "Argentina", "Bahamas", "Barbados", "Belize", "Bolivia", "Brazil", "Canada", "Chile", "Colombia",
    "Costa Rica", "Cuba", "Dominica", "Dominican Republic", "Ecuador", "El Salvador", "Grenada", "Guatemala", "Guyana", "Haiti",
    "Honduras", "Jamaica", "Mexico", "Nicaragua", "Panama", "Paraguay", "Peru", "Saint Kitts and Nevis", "Saint Lucia",
    "Saint Vincent and the Grenadines", "Suriname", "Trinidad and Tobago", "United States", "Uruguay", "Venezuela"
  ],
  "Asia": [
    "Afghanistan", "Bahrain", "Bangladesh", "Bhutan", "Brunei", "Cambodia", "China", "India", "Indonesia", "Iran", "Iraq",
    "Israel", "Japan", "Jordan", "Kazakhstan", "Kuwait", "Kyrgyzstan", "Laos", "Lebanon", "Malaysia", "Maldives", "Mongolia",
    "Myanmar (Burma)", "Nepal", "North Korea", "Oman", "Pakistan", "Palestine", "Philippines", "Qatar", "Saudi Arabia",
    "Singapore", "South Korea", "Sri Lanka", "Syria", "Taiwan", "Tajikistan", "Thailand", "Timor-Leste", "Turkey",
    "Turkmenistan", "United Arab Emirates", "Uzbekistan", "Vietnam", "Yemen"
  ],
  "Europe": [
    "Albania", "Andorra", "Austria", "Belarus", "Belgium", "Bosnia and Herzegovina", "Bulgaria", "Croatia", "Cyprus",
    "Czech Republic", "Denmark", "Estonia", "Finland", "France", "Germany", "Greece", "Hungary", "Iceland", "Ireland", "Italy",
    "Kosovo", "Latvia", "Liechtenstein", "Lithuania", "Luxembourg", "Malta", "Moldova", "Monaco", "Montenegro", "Netherlands",
    "North Macedonia", "Norway", "Poland", "Portugal", "Romania", "Russia", "San Marino", "Serbia", "Slovakia", "Slovenia",
      "Spain", "Sweden", "Switzerland", "Ukraine", "United Kingdom", "Vatican City"
  ],
  "Oceania": [
    "Australia", "Fiji", "Kiribati", "Marshall Islands", "Micronesia", "Nauru", "New Zealand", "Palau", "Papua New Guinea",
    "Samoa", "Solomon Islands", "Tonga", "Tuvalu", "Vanuatu"
  ]
};

const topCountries = ["United States", "United Kingdom", "Canada"];
const otherCountries = Object.values(countries).flat().filter(c => !topCountries.includes(c)).sort();
const allCountries = [...topCountries, ...otherCountries];

const devices = ["Smart TV (Samsung, LG)", "Amazon Firestick", "Android Box / TV", "Apple TV", "Formuler", "Roku", "iOS (iPhone, iPad)", "Android (Phone, Tablet)", "PC/Laptop (Windows, Mac)", "MAG Box", "Enigma2"];

const defaultPlayers = ["IPTV Smarters Pro", "TiviMate", "GSE Smart IPTV", "Perfect Player", "I don't have a player"];

const devicePlayerMap: Record<string, string[]> = {
  "Smart TV (Samsung, LG)": ["Ibo Player", "Tivimate", "IPTV Smarters Pro", "Hot Player", "I don't have a player"],
  "Amazon Firestick": ["TiviMate", "IPTV Smarters Pro", "GSE Smart IPTV", "Ibo Player Pro", "Chillio", "Bob Player", "Opus IPTV", "Ipexo Player", "I don't have a player"],
  "Android Box / TV": ["TiviMate", "IPTV Smarters Pro", "Perfect Player", "Ibo Player Pro", "Chillio", "Bob Player", "Opus IPTV", "Ipexo Player", "I don't have a player"],
  "Apple TV": ["GSE Smart IPTV", "IPTV Smarters Pro", "Chillio", "I don't have a player"],
  "iOS (iPhone, iPad)": ["GSE Smart IPTV", "IPTV Smarters Pro", "Chillio", "I don't have a player"],
  "Android (Phone, Tablet)": ["IPTV Smarters Pro", "TiviMate", "GSE Smart IPTV", "Ibo Player Pro", "Chillio", "Bob Player", "Opus IPTV", "Ipexo Player", "I don't have a player"],
};

export interface CustomerInfo {
    trialServerType: string;
    country: string;
    device: string;
    player: string;
    macAddress: string;
}

interface CustomerInfoFormProps {
  onFormCompletionChange: (isComplete: boolean) => void;
  onCustomerInfoChange: (info: CustomerInfo) => void;
}


export function CustomerInfoForm({ onFormCompletionChange, onCustomerInfoChange }: CustomerInfoFormProps) {
  const searchParams = useSearchParams();
  const isFreeTrial = searchParams.get('trial') === 'true';

  const [info, setInfo] = useState<CustomerInfo>({
    trialServerType: 'pro',
    country: '',
    device: '',
    player: '',
    macAddress: '',
  });

  const [availablePlayers, setAvailablePlayers] = useState(defaultPlayers);

  const isMacDevice = info.device === "MAG Box" || info.device === "Enigma2";

  useEffect(() => {
    onCustomerInfoChange(info);
    const isComplete = !!info.country && !!info.device;
    onFormCompletionChange(isComplete);
  }, [info, onFormCompletionChange, onCustomerInfoChange]);

  const handleInfoChange = <K extends keyof CustomerInfo>(key: K, value: CustomerInfo[K]) => {
    setInfo(prev => ({ ...prev, [key]: value }));
  };
  
  const handleDeviceChange = (device: string) => {
    handleInfoChange('device', device);
    setAvailablePlayers(devicePlayerMap[device] || defaultPlayers);
    // Reset player/mac if device type changes
    handleInfoChange('player', '');
    handleInfoChange('macAddress', '');
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-2xl font-headline text-primary">Your Information</CardTitle>
        <CardDescription>
            This helps us configure your service for the best experience.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form className="space-y-6">
          {isFreeTrial && (
             <div className="space-y-2">
                <Label className="flex items-center gap-2 text-base">
                    <Server className="h-5 w-5 text-primary" />
                    Trial Server Type
                </Label>
                <RadioGroup 
                  value={info.trialServerType} 
                  className="flex flex-wrap gap-4 pt-2" 
                  onValueChange={(value) => handleInfoChange('trialServerType', value)}
                >
                    <div className="flex items-center space-x-2">
                        <RadioGroupItem value="pro" id="pro-trial" />
                        <Label htmlFor="pro-trial">Pro Server</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                        <RadioGroupItem value="basic" id="basic-trial" />
                        <Label htmlFor="basic-trial">Basic Server</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                        <RadioGroupItem value="both" id="both-trial" />
                        <Label htmlFor="both-trial">Both Servers</Label>
                    </div>
                </RadioGroup>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="country" className="flex items-center gap-2 text-base">
                <Globe className="h-5 w-5 text-primary" />
                Country
            </Label>
            <Select value={info.country} onValueChange={(value) => handleInfoChange('country', value)}>
              <SelectTrigger id="country">
                <SelectValue placeholder="Select your country" />
              </SelectTrigger>
              <SelectContent>
                {allCountries.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="device" className="flex items-center gap-2 text-base">
                <Tv className="h-5 w-5 text-primary" />
                Device Type
            </Label>
            <Select value={info.device} onValueChange={handleDeviceChange}>
              <SelectTrigger id="device">
                <SelectValue placeholder="Select your device" />
              </SelectTrigger>
              <SelectContent>
                {devices.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          
          {isMacDevice ? (
            <div className="space-y-2">
                <Label htmlFor="mac-address" className="flex items-center gap-2 text-base">
                    <Fingerprint className="h-5 w-5 text-primary" />
                    MAC Address
                </Label>
                <Input 
                    id="mac-address" 
                    placeholder="00:1A:79:XX:XX:XX"
                    value={info.macAddress}
                    onChange={(e) => handleInfoChange('macAddress', e.target.value)}
                />
            </div>
          ) : (
            <div className="space-y-2">
                <Label htmlFor="player" className="flex items-center gap-2 text-base">
                    <PlaySquare className="h-5 w-5 text-primary" />
                    IPTV Player
                </Label>
                <Select value={info.player} onValueChange={(value) => handleInfoChange('player', value)} disabled={!info.device}>
                  <SelectTrigger id="player">
                    <SelectValue placeholder="Select your IPTV player" />
                  </SelectTrigger>
                  <SelectContent>
                    {availablePlayers.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                  </SelectContent>
                </Select>
            </div>
          )}

        </form>
      </CardContent>
    </Card>
  );
}
