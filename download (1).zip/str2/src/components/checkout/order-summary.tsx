'use client';

import { useSearchParams } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '../ui/badge';
import { ShieldCheck } from 'lucide-react';

interface OrderSummaryProps {
    trialServerType?: string;
}

export function OrderSummary({ trialServerType }: OrderSummaryProps) {
  const searchParams = useSearchParams();
  const isFreeTrial = searchParams.get('trial') === 'true';

  const plan = searchParams.get('plan') || 'Pro';
  const duration = isFreeTrial ? '24 Hours' : searchParams.get('duration') || '6 Months';
  const price = searchParams.get('price');
  const originalPrice = searchParams.get('originalPrice');
  const connections = searchParams.get('connections') || '1';

  const getTrialServerText = () => {
    if (!trialServerType) return "Pro";
    if (trialServerType === 'basic') return 'Basic';
    if (trialServerType === 'pro') return 'Pro';
    if (trialServerType === 'both') return 'Both Servers';
    return 'Pro';
  };
  
  const savedPercentage = originalPrice && price ? Math.round(((parseInt(originalPrice, 10) - parseInt(price, 10)) / parseInt(originalPrice, 10)) * 100) : 0;
  
  const getGuaranteePeriod = () => {
    if (!duration) return null;
    const lowerCaseDuration = duration.toLowerCase();
    if (lowerCaseDuration.includes('1 month')) return '1 Day';
    if (lowerCaseDuration.includes('3 months')) return '3 Days';
    if (lowerCaseDuration.includes('6 months') || lowerCaseDuration.includes('year')) return '7 Days';
    return null;
  };
  
  const guaranteePeriod = getGuaranteePeriod();

  return (
    <Card className="bg-card/50 shadow-lg border-primary/20 w-full relative overflow-hidden">
      {savedPercentage > 0 && !isFreeTrial && (
        <Badge variant="destructive" className="absolute top-4 right-4 text-sm">
            Save {savedPercentage}%
        </Badge>
      )}
      <CardHeader>
        <CardTitle className="text-2xl font-headline text-primary">
          {isFreeTrial ? 'Your 24-Hour Free Trial' : 'Order Summary'}
        </CardTitle>
        <CardDescription>
            {isFreeTrial 
                ? 'You are requesting a full-featured free trial.' 
                : 'Review the details of your selected plan.'
            }
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
            <div className="flex justify-between items-center">
                <span className="text-foreground/80">Plan:</span>
                <span className="font-bold text-card-foreground">{isFreeTrial ? getTrialServerText() : plan}</span>
            </div>
            <div className="flex justify-between items-center">
                <span className="text-foreground/80">Subscription:</span>
                <span className="font-bold text-card-foreground">{duration}</span>
            </div>
            <div className="flex justify-between items-center">
                <span className="text-foreground/80">Connections:</span>
                <span className="font-bold text-card-foreground">{connections} Device(s)</span>
            </div>
        </div>
        
        {!isFreeTrial && price && (
            <>
                <Separator />
                <div className="flex justify-between items-center text-xl mt-6">
                    <span className="font-headline text-card-foreground">Total Price:</span>
                    <div className="flex items-baseline gap-2">
                        {originalPrice && parseInt(originalPrice, 10) > parseInt(price, 10) && (
                            <span className="text-lg line-through text-muted-foreground">
                                ${originalPrice}
                            </span>
                        )}
                        <span className="font-bold text-primary text-2xl">${price}</span>
                    </div>
                </div>
            </>
        )}
      </CardContent>
       <CardFooter className='flex-col items-start gap-4'>
        {isFreeTrial && (
          <p className='text-xs text-muted-foreground'>* Your trial gives you full access for 24 hours.</p>
        )}
        {!isFreeTrial && guaranteePeriod && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <ShieldCheck className="h-5 w-5 text-green-500" />
            <span><strong>{guaranteePeriod}</strong> Money-Back Guarantee included.</span>
          </div>
        )}
      </CardFooter>
    </Card>
  );
}
