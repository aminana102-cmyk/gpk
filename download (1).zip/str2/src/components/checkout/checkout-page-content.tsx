
'use client';

import { useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { OrderSummary } from '@/components/checkout/order-summary';
import { PaymentInstructions } from '@/components/checkout/payment-instructions';
import { FadeIn } from '@/components/fade-in';
import { CustomerInfoForm, type CustomerInfo } from '@/components/checkout/customer-info-form';
import { PlanFeatures } from '@/components/checkout/plan-features';

export function CheckoutPageContent() {
  const searchParams = useSearchParams();
  const isFreeTrial = searchParams.get('trial') === 'true';
  const planFromUrl = searchParams.get('plan') || 'Pro';

  const [customerInfo, setCustomerInfo] = useState<CustomerInfo>({
    trialServerType: 'pro',
    country: '',
    device: '',
    player: '',
    macAddress: '',
  });

  const [isFormComplete, setIsFormComplete] = useState(false);

  const getPlanName = () => {
    if (isFreeTrial) {
      if (customerInfo.trialServerType === 'basic') return 'Basic';
      // For 'pro' or 'both', show Pro features
      return 'Pro';
    }
    return planFromUrl;
  };

  const planName = getPlanName();

  const handleFormCompletionChange = (isComplete: boolean) => {
    setIsFormComplete(isComplete);
  };

  const handleCustomerInfoChange = (info: CustomerInfo) => {
    setCustomerInfo(info);
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 py-8">
      <FadeIn>
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-3xl md:text-5xl font-extrabold font-headline text-primary">
            Complete Your Order
          </h1>
          <p className="mt-2 text-base md:text-lg text-foreground/80">
            You're just one step away from unlimited entertainment. Please review your order and follow the instructions to activate your subscription.
          </p>
        </div>
      </FadeIn>

      <div className="mt-8 max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        <div className="w-full space-y-8">
          <FadeIn delay={200}>
            <OrderSummary trialServerType={isFreeTrial ? customerInfo.trialServerType : undefined} />
          </FadeIn>
          <FadeIn delay={300}>
            <CustomerInfoForm onFormCompletionChange={handleFormCompletionChange} onCustomerInfoChange={handleCustomerInfoChange} />
          </FadeIn>
        </div>
        <div className="w-full space-y-8 lg:sticky lg:top-24">
          <FadeIn delay={400} className="w-full">
            <PaymentInstructions isFormComplete={isFormComplete} customerInfo={customerInfo} />
          </FadeIn>
          <FadeIn delay={500}>
            <PlanFeatures planName={planName} />
          </FadeIn>
        </div>
      </div>
    </div>
  );
}
