'use client';

import { useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '../ui/button';
import { CreditCard, Bitcoin, ArrowRight, CheckCircle, Landmark, Globe, Banknote } from 'lucide-react';
import { Label } from "@/components/ui/label"
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription, 
  DialogTrigger 
} from '../ui/dialog';
import type { CustomerInfo } from './customer-info-form';
import { cn } from '@/lib/utils';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';

interface PaymentInstructionsProps {
  isFormComplete: boolean;
  customerInfo: CustomerInfo;
}

const WhatsAppIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="currentColor"
    {...props}
  >
    <path
        d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.79.46 3.48 1.32 4.95L2 22l5.25-1.38c1.41.81 3.02 1.3 4.79 1.3h.01c5.46 0 9.91-4.45 9.91-9.91S17.5 2 12.04 2M12.04 20.15h-.01c-1.55 0-3.04-.42-4.32-1.2L3.84 20l1.24-3.87c-.87-1.32-1.36-2.9-1.36-4.59C3.72 7.42 7.47 3.67 12.04 3.67s8.31 3.75 8.31 8.32-3.75 8.16-8.31 8.16m4.8-6.13c-.28-.14-1.65-.81-1.9-.91-.25-.1-.44-.14-.62.14s-.72.91-.88 1.1c-.16.19-.32.21-.6.07-.28-.13-1.18-.44-2.25-1.39s-1.76-2.1-2.06-2.45c-.3-.35-.03-.55.12-.68.13-.12.28-.31.42-.47.14-.16.19-.28.28-.47.1-.19.05-.36-.02-.5s-.62-1.5-.85-2.06c-.23-.56-.46-.48-.62-.49-.16-.01-.34-.01-.53-.01s-.46.07-.7.35c-.24.28-.92.89-1.18 2.16-.26 1.27.35 2.59.4 2.77.05.18 1.18 1.8 2.86 2.53.23.1.42.16.6.21.46.17.88.14 1.21.09.37-.06 1.18-.48 1.34-.94.17-.46.17-.85.12-.94-.05-.09-.19-.14-.42-.26"
    />
  </svg>
);

const TelegramIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="currentColor"
      {...props}
    >
      <path d="M22 2 2 9.17l6.87 2.75L16.25 6 9.9 12.89l.2 6.5 3.3-3.1 3.44 2.6L22 2z" />
    </svg>
  );
  
const trialFeatures = [
    "Trial period up to 36 hours",
    "Human assistance if you don't have an IPTV player",
    "Test multiple servers, not just one",
    "Full support during the trial period",
];

const paymentMethods = [
    { name: 'Credit/Debit Card', icon: CreditCard, note: 'via Crypto Purchase', country: 'all' },
    { name: 'PayPal', icon: Banknote, country: 'all' },
    { name: 'Cryptocurrency', icon: Bitcoin, country: 'all' },
    { name: 'Bank Transfer (ACH)', icon: Landmark, country: 'United States' },
    { name: 'Western Union', icon: Globe, country: 'all' },
    { name: 'Remitly', icon: Globe, country: 'all' },
    { name: 'Ria', icon: Globe, country: 'all' },
    { name: 'MoneyGram', icon: Globe, country: 'all' },
    { name: 'Xoom', icon: Globe, country: 'all' },
];

export function PaymentInstructions({ isFormComplete, customerInfo }: PaymentInstructionsProps) {
  const searchParams = useSearchParams();
  const isFreeTrial = searchParams.get('trial') === 'true';

  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('');

  const plan = searchParams.get('plan') || 'Pro';
  const duration = searchParams.get('duration') || '6 Months';
  const price = searchParams.get('price') || '45';
  const connections = searchParams.get('connections') || '1';

  const title = isFreeTrial ? 'Activate Your Free Trial' : 'How to Complete Your Payment';
  const description = isFreeTrial
    ? 'To activate your 24-hour free trial, please contact our support team. We will set up your account instantly!'
    : 'After filling in your details, please select a payment method and contact us to complete your purchase.';

  const buildMessage = () => {
    if (!isFormComplete) return '';

    let message = '';
    if (isFreeTrial) {
      message = `Hello IPTV THE FOX,

I would like to request a free trial with the following details:

- Request: Free Trial
- Server Type: ${customerInfo.trialServerType.charAt(0).toUpperCase() + customerInfo.trialServerType.slice(1)}
- Country: ${customerInfo.country}
- Device: ${customerInfo.device}`;
      if (customerInfo.macAddress) {
        message += `\n- MAC Address: ${customerInfo.macAddress}`;
      } else if (customerInfo.player) {
        message += `\n- Player: ${customerInfo.player}`;
      }
    } else {
        message = `Hello IPTV THE FOX,

I would like to purchase a subscription with the following details:

- Plan: ${plan}
- Duration: ${duration}
- Connections: ${connections}
- Total Price: $${price}
-----------------------------
- Country: ${customerInfo.country}
- Device: ${customerInfo.device}`;
      if (customerInfo.macAddress) {
        message += `\n- MAC Address: ${customerInfo.macAddress}`;
      } else if (customerInfo.player) {
        message += `\n- Player: ${customerInfo.player}`;
      }
      if (selectedPaymentMethod) {
          message += `\n- Preferred Payment Method: ${selectedPaymentMethod}`;
      }
    }
    
    message += '\n\nThank you!';
    return encodeURIComponent(message);
  };
  
  const WHATSAPP_LINK = `https://wa.me/212629095943?text=${buildMessage()}`;
  const TELEGRAM_LINK = `https://t.me/ZYNN_TV?text=${buildMessage()}`;

  const isContinueDisabled = !isFormComplete || (!isFreeTrial && !selectedPaymentMethod);


  const ContactLink = ({ href, children, variant, icon: Icon, className: extraClassName }: { href: string, children: React.ReactNode, variant: 'primary' | 'secondary' | 'whatsapp', icon: React.ElementType, className?: string }) => (
    <Button
      asChild
      variant={variant === 'whatsapp' ? 'whatsapp' : 'primary'}
      className={`w-full h-14 text-lg font-bold transition-all duration-300 transform hover:scale-105 ${extraClassName}`}
    >
      <a href={href} target="_blank" rel="noopener noreferrer" >
        <Icon className="h-6 w-6 mr-3" />
        {children}
      </a>
    </Button>
  );

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-2xl font-headline text-primary">{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        {!isFreeTrial && (
            <div className="mb-6 space-y-2">
                <Label htmlFor="payment-method" className="font-headline text-lg text-card-foreground">Select a Payment Method:</Label>
                <Select value={selectedPaymentMethod} onValueChange={setSelectedPaymentMethod}>
                    <SelectTrigger id="payment-method">
                        <SelectValue placeholder="Choose a payment option" />
                    </SelectTrigger>
                    <SelectContent>
                        {paymentMethods.map(method => {
                             if (method.country !== 'all' && customerInfo.country !== method.country) {
                                return null;
                            }
                            return (
                                <SelectItem key={method.name} value={method.name}>
                                    <div className="flex items-center gap-3">
                                        <method.icon className="h-5 w-5 text-muted-foreground" />
                                        <span>{method.name}</span>
                                        {method.note && <span className='text-xs text-muted-foreground'>({method.note})</span>}
                                    </div>
                                </SelectItem>
                            )
                        })}
                    </SelectContent>
                </Select>
            </div>
        )}

        {!isFormComplete && (
            <p className="text-sm text-center text-orange-500 mb-4 font-semibold">
                Please fill in your Country and Device first.
            </p>
        )}
        
        <Dialog>
          <DialogTrigger asChild>
            <Button 
              className="w-full h-12 text-lg font-bold" 
              disabled={isContinueDisabled}
            >
              Continue <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="text-2xl font-headline text-primary">Choose Contact Method</DialogTitle>
                <DialogDescription>
                    {isFreeTrial ? "Contact us to get your free trial. You will get:" : "Select your preferred app to get in touch with our team. We're ready to help you 24/7."}
                </DialogDescription>
            </DialogHeader>
            {isFreeTrial && (
                 <ul className="space-y-2 pt-2">
                    {trialFeatures.map((feature, index) => (
                        <li key={index} className="flex items-start gap-3">
                            <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-1" />
                            <span className="text-sm text-foreground/90">{feature}</span>
                        </li>
                    ))}
                </ul>
            )}
            <div className="space-y-4 pt-4">
              <ContactLink href={WHATSAPP_LINK} variant="whatsapp" icon={WhatsAppIcon} className="bg-[#25D366] text-white hover:bg-[#25D366]/90">
                Chat on WhatsApp
              </ContactLink>
              <ContactLink href={TELEGRAM_LINK} variant="primary" icon={TelegramIcon} className="bg-[#0088cc] hover:bg-[#0088cc]/90">
                Contact on Telegram
              </ContactLink>
            </div>
          </DialogContent>
        </Dialog>

        <div className="mt-6 text-center">
            <p className="text-sm text-muted-foreground">Our support team is available 24/7 to assist you.</p>
        </div>
      </CardContent>
    </Card>
  );
}
