import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Check } from "lucide-react";

const proPlanFeatures = [
    'More +41,000 Channels',
    '+130,000 VOD TV & Movies',
    '4K / FHD / HD Quality',
    'No Freezing Fast & Stable',
    'Premium Quality Server',
    'Supported all Devices',
    'Money-Back Guarantee',
    'Available Worldwide',
    'EPG & catch-up',
    '%99.99 Uptime',
    'Exclusive Sports Channels',
    'Priority 24/7 Support',
];

const basicPlanFeatures = [
      'More +20,000 Channels',
      '+80,000 VOD TV & Movies',
      'FHD & HD Channels',
      'Some 4K Channels',
      'No Freezing Fast & Stable',
      'Premium Quality Server',
      'Supported all Devices',
      'Money-Back Guarantee',
      'Available Worldwide',
      'EPG & catch-up',
      '%99.99 Uptime',
];

interface PlanFeaturesProps {
    planName: string;
}

export function PlanFeatures({ planName }: PlanFeaturesProps) {
    const features = planName.toLowerCase() === 'basic' ? basicPlanFeatures : proPlanFeatures;

    return (
        <Card>
            <CardHeader>
                <CardTitle className="text-2xl font-headline text-primary">Features Included</CardTitle>
            </CardHeader>
            <CardContent>
                <ul className="space-y-2">
                    {features.map((feature, index) => (
                        <li key={index} className="flex items-center gap-3">
                            <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                            <span className="text-sm text-foreground/90">{feature}</span>
                        </li>
                    ))}
                </ul>
            </CardContent>
        </Card>
    )
}
