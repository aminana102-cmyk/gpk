'use client';

import { useState, useMemo, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle, Clapperboard } from 'lucide-react';
import { FadeIn } from '@/components/fade-in';
import { ScrollArea } from '@/components/ui/scroll-area';

const africanCountriesList = new Set([
    "Algeria", "Angola", "Benin", "Botswana", "Burkina Faso", "Burundi", "Cabo Verde", "Cameroon", "Central African Republic",
    "Chad", "Comoros", "Congo, Democratic Republic of the", "Congo, Republic of the", "Cote d'Ivoire", "Djibouti", "Egypt",
    "Equatorial Guinea", "Eritrea", "Eswatini", "Ethiopia", "Gabon", "Gambia", "Ghana", "Guinea", "Guinea-Bissau", "Kenya",
    "Lesotho", "Liberia", "Libya", "Madagascar", "Malawi", "Mali", "Mauritania", "Mauritius", "Morocco", "Mozambique", "Namibia",
    "Niger", "Nigeria", "Rwanda", "Sao Tome and Principe", "Senegal", "Seychelles", "Sierra Leone", "Somalia", "South Africa",
    "South Sudan", "Sudan", "Tanzania", "Togo", "Tunisia", "Uganda", "Zambia", "Zimbabwe"
]);

const countryData = [
    // Top-tier
    { name: "USA", flag: "🇺🇸", type: 'country' },
    { name: "United Kingdom", flag: "🇬🇧", type: 'country' },
    { name: "Canada", flag: "🇨🇦", type: 'country' },
    // Europe
    { name: "France", flag: "🇫🇷", type: 'country' }, { name: "Spain", flag: "🇪🇸", type: 'country' }, { name: "Germany", flag: "🇩🇪", type: 'country' },
    { name: "Switzerland", flag: "🇨🇭", type: 'country' }, { name: "Austria", flag: "🇦🇹", type: 'country' }, { name: "Portugal", flag: "🇵🇹", type: 'country' },
    { name: "Italy", flag: "🇮🇹", type: 'country' }, { name: "Netherlands", flag: "🇳🇱", type: 'country' }, { name: "Belgium", flag: "🇧🇪", type: 'country' },
    { name: "Poland", flag: "🇵🇱", type: 'country' }, { name: "Greece", flag: "🇬🇷", type: 'country' },
    { name: "Armenia", flag: "🇦🇲", type: 'country' }, { name: "Malta", flag: "🇲🇹", type: 'country' }, { name: "Sweden", flag: "🇸🇪", type: 'country' },
    { name: "Denmark", flag: "🇩🇰", type: 'country' }, { name: "Norway", flag: "🇳🇴", type: 'country' }, { name: "Finland", flag: "🇫🇮", type: 'country' },
    { name: "Albania", flag: "🇦🇱", type: 'country' }, { name: "Slovenia", flag: "🇸🇮", type: 'country' }, { name: "Lithuania", flag: "🇱🇹", type: 'country' },
    { name: "Latvia", flag: "🇱🇻", type: 'country' }, { name: "Estonia", flag: "🇪🇪", type: 'country' }, { name: "Hungary", flag: "🇭🇺", type: 'country' },
    { name: "Czech Republic", flag: "🇨🇿", type: 'country' }, { name: "Romania", flag: "🇷🇴", type: 'country' }, { name: "Bulgaria", flag: "🇧🇬", type: 'country' },
    { name: "Russia", flag: "🇷🇺", type: 'country' }, { name: "Ukraine", flag: "🇺🇦", type: 'country' }, { name: "Georgia", flag: "🇬🇪", type: 'country' },
    // Americas
    { name: "Brazil", flag: "🇧🇷", type: 'country' },
    { name: "Mexico", flag: "🇲🇽", type: 'country' },
    { name: "Argentina", flag: "🇦🇷", type: 'country' },
    // Asia & Oceania
    { name: "Australia", flag: "🇦🇺", type: 'country' }, { name: "New Zealand", flag: "🇳🇿", type: 'country' },
    { name: "India", flag: "🇮🇳", type: 'country' }, { name: "Turkey", flag: "🇹🇷", type: 'country' }, { name: "Iran", flag: "🇮🇷", type: 'country' },
    { name: "Afghanistan", flag: "🇦🇫", type: 'country' }, { name: "Pakistan", flag: "🇵🇰", type: 'country' }, { name: "Azerbaijan", flag: "🇦🇿", type: 'country' },
    { name: "Uzbekistan", flag: "🇺🇿", type: 'country' }, { name: "Tajikistan", flag: "🇹🇯", type: 'country' }, { name: "China", flag: "🇨🇳", type: 'country' },
    { name: "South Korea", flag: "🇰🇷", type: 'country' }, { name: "Indonesia", flag: "🇮🇩", type: 'country' }, { name: "Myanmar", flag: "🇲🇲", type: 'country' },
    { name: "Thailand", flag: "🇹🇭", type: 'country' }, { name: "Singapore", flag: "🇸🇬", type: 'country' }, { name: "Taiwan", flag: "🇹🇼", type: 'country' },
    { name: "Vietnam", flag: "🇻🇳", type: 'country' }, { name: "Malaysia", flag: "🇲🇾", type: 'country' }, { name: "Japan", flag: "🇯🇵", type: 'country' },
    { name: "Philippines", flag: "🇵🇭", type: 'country' },
    // Africa & Others
    { name: "Suriname", flag: "🇸🇷", type: 'country' },
    { name: "Africa", flag: "🌍", type: 'country' }, { name: "Nigeria", flag: "🇳🇬", type: 'country'}, { name: "Egypt", flag: "🇪🇬", type: 'country'},
    { name: "South Africa", flag: "🇿🇦", type: 'country'}, { name: "Ghana", flag: "🇬🇭", type: 'country'}, { name: "Kenya", flag: "🇰🇪", type: 'country'},
    { name: "Morocco", flag: "🇲🇦", type: 'country'}, { name: "Ethiopia", flag: "🇪🇹", type: 'country'}, { name: "Tanzania", flag: "🇹🇿", type: 'country'}
];

const platformData = [
    // Global & US
    { name: "Netflix", type: 'platform' },
    { name: "Amazon Prime Video", type: 'platform' },
    { name: "Disney+", type: 'platform' },
    { name: "HBO Max", type: 'platform' },
    { name: "Hulu", type: 'platform' },
    { name: "Apple TV+", type: 'platform' },
    { name: "YouTube TV", type: 'platform' },
    { name: "Sling TV", type: 'platform' },
    { name: "Peacock", type: 'platform' },
    { name: "Paramount+", type: 'platform' },
    { name: "Discovery+", type: 'platform' },
    { name: "Starz", type: 'platform' },
    { name: "Showtime", type: 'platform' },
    { name: "MGM+", type: 'platform' },
    { name: "FuboTV", type: 'platform' },
    { name: "Philo", type: 'platform' },
    { name: "Tubi", type: 'platform' },
    { name: "Pluto TV", type: 'platform' },
    // UK
    { name: "BBC iPlayer", type: 'platform' },
    { name: "ITV Hub", type: 'platform' },
    { name: "All 4", type: 'platform' },
    { name: "Sky Go", type: 'platform' },
    { name: "Now TV", type: 'platform' },
    { name: "BritBox", type: 'platform' },
    // Canada
    { name: "Crave", type: 'platform' },
    { name: "CBC Gem", type: 'platform' },
    { name: "Global TV", type: 'platform' },
    // International / Niche
    { name: "Crunchyroll", type: 'platform' },
    { name: "DAZN", type: 'platform' },
    { name: "CuriosityStream", type: 'platform' },
    { name: "MUBI", type: 'platform' },
    { name: "Acorn TV", type: 'platform' },
    { name: "Shudder", type: 'platform' },
    { name: "Shahid", type: 'platform' },
    { name: "OSN", type: 'platform' },
    { name: "Viu", type: 'platform' },
    { name: "iQIYI", type: 'platform' },
    { name: "Hotstar", type: 'platform' },
    { name: "SonyLIV", type: 'platform' },
];

const turkishChannels = [
    { name: "BeIN Sports Turkey", type: 'platform' },
    { name: "Digiturk", type: 'platform' },
    { name: "D-Smart", type: 'platform' },
    { name: "Tivibu", type: 'platform' },
    { name: "Exxen", type: 'platform' },
    { name: "BluTV", type: 'platform' },
    { name: "Puhu TV", type: 'platform' },
    { name: "S Sport", type: 'platform' },
    { name: "TRT 1", type: 'platform' },
    { name: "ATV", type: 'platform' },
    { name: "Kanal D", type: 'platform' },
    { name: "Show TV", type: 'platform' },
    { name: "Star TV", type: 'platform' },
    { name: "Fox (Now)", type: 'platform' },
    { name: "TV8", type: 'platform' },
    { name: "NTV", type: 'platform' },
    { name: "CNN Türk", type: 'platform' },
    { name: "HaberTürk", type: 'platform' },
    { name: "A Spor", type: 'platform' },
    { name: "TRT Spor", type: 'platform' },
];

const newsAndSportsChannels = [
    // News
    { name: "CNN", type: 'platform' },
    { name: "BBC World News", type: 'platform' },
    { name: "Fox News", type: 'platform' },
    { name: "MSNBC", type: 'platform' },
    { name: "Sky News", type: 'platform' },
    { name: "Al Jazeera", type: 'platform' },
    { name: "Euronews", type: 'platform' },
    { name: "CNBC", type: 'platform' },
    { name: "Bloomberg", type: 'platform' },
    { name: "France 24", type: 'platform' },
    // US Sports
    { name: "ESPN+", type: 'platform' },
    { name: "Fox Sports (FS1)", type: 'platform' },
    { name: "NBC Sports", type: 'platform' },
    { name: "CBS Sports", type: 'platform' },
    { name: "NFL Network", type: 'platform' },
    { name: "NBA TV", type: 'platform' },
    { name: "MLB Network", type: 'platform' },
    { name: "NHL Network", type: 'platform' },
    { name: "UFC Fight Pass", type: 'platform' },
    { name: "WWE Network", type: 'platform' },
    { name: "beIN Sports", type: 'platform' },
    // UK Sports
    { name: "Sky Sports", type: 'platform' },
    { name: "BT Sport (TNT Sports)", type: 'platform' },
    // International Sports
    { name: "Eurosport", type: 'platform' },
    { name: "SuperSport", type: 'platform' },
    { name: "Ten Sports", type: 'platform' },
    { name: "Star Sports", type: 'platform' },
    // Premium Networks
    { name: "AMC+", type: 'platform' },
    { name: "Discovery Channel", type: 'platform' },
    { name: "National Geographic", type: 'platform' },
    { name: "History Channel", type: 'platform' },
    { name: "A&E", type: 'platform' },
    { name: "Bravo", type: 'platform' },
    { name: "FX", type: 'platform' },
    { name: "Syfy", type: 'platform' },
    { name: "USA Network", type: 'platform' },
    { name: "TBS", type: 'platform' },
    { name: "TNT", type: 'platform' },
    { name: "MTV", type: 'platform' },
    { name: "Comedy Central", type: 'platform' },
    { name: "Cartoon Network", type: 'platform' },
    { name: "Nickelodeon", type: 'platform' },
];


const allData = [...countryData, ...platformData, ...turkishChannels, ...newsAndSportsChannels].sort((a, b) => {
    const topCountries = ["USA", "United Kingdom", "Canada"];
    const aIsTop = a.type === 'country' && topCountries.includes(a.name);
    const bIsTop = b.type === 'country' && topCountries.includes(b.name);

    if (aIsTop && !bIsTop) return -1;
    if (!aIsTop && bIsTop) return 1;
    if (aIsTop && bIsTop) return topCountries.indexOf(a.name) - topCountries.indexOf(b.name);

    if (a.type === 'country' && b.type === 'platform') return -1;
    if (a.type === 'platform' && b.type === 'country') return 1;

    return a.name.localeCompare(b.name);
});


export function ChannelList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  const filteredData = useMemo(() => {
    if (!searchTerm) return allData;

    const lowerCaseSearchTerm = searchTerm.toLowerCase();

    let results = allData.filter(item =>
      item.name.toLowerCase().includes(lowerCaseSearchTerm)
    );

    const searchedCountryIsAfrican = Array.from(africanCountriesList).some(africanCountry =>
        africanCountry.toLowerCase().includes(lowerCaseSearchTerm)
    );

    if ((lowerCaseSearchTerm === 'africa' || searchedCountryIsAfrican) && !results.some(c => c.name === "Africa")) {
      const africaEntry = allData.find(c => c.name === "Africa");
      if (africaEntry && !results.some(r => r.name === 'Africa')) {
        results.push(africaEntry);
        results.sort((a, b) => a.name.localeCompare(b.name));
      }
    }

    return results;
  }, [searchTerm]);

  if (!mounted) {
    return null; // or a loading skeleton
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-center">
        <Input
          placeholder="Search for a country or platform..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-md text-base"
        />
      </div>
      <FadeIn delay={100}>
        <Card>
            <ScrollArea className="h-[600px]">
              <CardContent className="p-0">
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-px bg-border">
                  {filteredData.map((item, index) => (
                    <div key={index} className="bg-card p-4 flex flex-col items-center justify-center text-center space-y-2 aspect-square transition-all duration-300 hover:bg-muted/50 transform hover:-translate-y-1">
                      {item.type === 'country' ? (
                        <span className="text-4xl">{(item as any).flag}</span>
                      ) : (
                        <Clapperboard className="h-10 w-10 text-primary" />
                      )}
                      <p className="font-headline font-semibold text-sm text-card-foreground">{item.name}</p>
                       <div className="flex items-center gap-2 text-orange-500">
                            <CheckCircle className="h-4 w-4" />
                            <span className="text-xs font-medium">Available</span>
                       </div>
                    </div>
                  ))}
                </div>
                {filteredData.length === 0 && (
                  <div className="text-center p-16 text-foreground/60">
                    <p className="text-lg">No results found matching your search.</p>
                  </div>
                )}
              </CardContent>
            </ScrollArea>
        </Card>
      </FadeIn>
    </div>
  );
}
