
'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const steps = [
  'Open the App Store on your iPhone or iPad.',
  'Tap the Search icon and type in "GSE Smart IPTV", "IPTV Smarters Lite", or "Chillio".',
  'Tap "Get" to download and install the application.',
  'Launch the app after it has been installed.',
  'Accept the terms and conditions, then look for an option to "Add Playlist" or use Xtream Codes API.',
  'Enter the login details (M3U Link or Xtream Codes) that were emailed to you after subscribing.',
  'Your playlist will now load. Enjoy streaming on the go!',
];

export function IosGuide() {
    return (
        <Card className="bg-card/50">
            <CardHeader>
            <CardTitle className="text-2xl font-headline text-primary">
                Setup on iOS (iPhone/iPad)
            </CardTitle>
            </CardHeader>
            <CardContent>
            <div className="space-y-4">
                {steps.map((step, index) => (
                    <div key={index} className="flex gap-4">
                    <div className="flex-shrink-0 h-8 w-8 rounded-full bg-orange-500 text-white flex items-center justify-center font-bold">
                        {index + 1}
                    </div>
                    <p className="text-foreground/90">{step}</p>
                    </div>
                ))}
            </div>
            </CardContent>
        </Card>
    )
}
