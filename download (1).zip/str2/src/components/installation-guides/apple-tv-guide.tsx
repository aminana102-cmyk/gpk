
'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const steps = [
  'From the home screen, open the App Store.',
  'Navigate to the Search tab and look for "GSE Smart IPTV", "IPTV Smarters Lite", or "Chillio".',
  'Select your chosen application and click "Get" to install it.',
  'Once installed, launch the app from your home screen.',
  'Find the option to add a new playlist, usually labeled "Add Playlist" or "+". Choose to log in with Xtream Codes API or M3U URL.',
  'Enter the credentials provided in your subscription email from IPTV THE FOX.',
  'Your channels will load automatically. Enjoy the show!',
];

export function AppleTvGuide() {
    return (
        <Card className="bg-card/50">
            <CardHeader>
            <CardTitle className="text-2xl font-headline text-primary">
                Setup on Apple TV
            </CardTitle>
            </CardHeader>
            <CardContent>
            <div className="space-y-4">
                {steps.map((step, index) => (
                    <div key={index} className="flex gap-4">
                    <div className="flex-shrink-0 h-8 w-8 rounded-full bg-orange-500 text-white flex items-center justify-center font-bold">
                        {index + 1}
                    </div>
                    <p className="text-foreground/90">{step}</p>
                    </div>
                ))}
            </div>
            </CardContent>
        </Card>
    )
}
