
'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const steps = [
  'Navigate to the App Store on your Smart TV.',
  'Search for an IPTV player app like "IPTV Smarters Pro", "Ibo Player", "Room IPTV", or "XCIPTV".',
  'Install and launch the application.',
  'Choose to log in with Xtream Codes API or M3U Playlist.',
  'Enter the credentials provided to you by IPTV THE FOX.',
  'Wait for the channels and VOD to load. Enjoy!',
];

export function SmartTvGuide() {
    return (
        <Card className="bg-card/50">
            <CardHeader>
            <CardTitle className="text-2xl font-headline text-primary">
                Setup on Smart TV (Samsung/LG)
            </CardTitle>
            </CardHeader>
            <CardContent>
            <div className="space-y-4">
                {steps.map((step, index) => (
                    <div key={index} className="flex gap-4">
                    <div className="flex-shrink-0 h-8 w-8 rounded-full bg-orange-500 text-white flex items-center justify-center font-bold">
                        {index + 1}
                    </div>
                    <p className="text-foreground/90">{step}</p>
                    </div>
                ))}
            </div>
            </CardContent>
        </Card>
    )
}
