
'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

const steps = [
  'Open the Google Play Store on your Android device.',
  'Search for and install an IPTV player like "TiviMate" or "IPTV Smarters".',
  'Once installed, open the app.',
  'You will be prompted to add a playlist. Choose either M3U URL or Xtream Codes login.',
  'Enter the details you received from us after subscribing.',
  'Your playlist will load, and you can start watching immediately.',
];

const IBO_PLAYER_PRO_LINK = "https://ibodesk.com/iboplayerpro.apk";

export function AndroidGuide() {
    return (
        <Card className="bg-card/50">
            <CardHeader>
            <CardTitle className="text-2xl font-headline text-primary">
                Setup on Android Box / Phone
            </CardTitle>
            </CardHeader>
            <CardContent>
            <div className="space-y-4">
                {steps.map((step, index) => (
                    <div key={index} className="flex gap-4">
                    <div className="flex-shrink-0 h-8 w-8 rounded-full bg-orange-500 text-white flex items-center justify-center font-bold">
                        {index + 1}
                    </div>
                    <p className="text-foreground/90">{step}</p>
                    </div>
                ))}
                <div className="pl-12 pt-4">
                <Card className='p-4 bg-background/50'>
                    <p className='text-sm text-foreground/80 mb-2'>Alternatively, you can download IBO Player Pro directly:</p>
                    <Button asChild>
                        <Link href={IBO_PLAYER_PRO_LINK} target="_blank" rel="noopener noreferrer">
                        Click here to download
                        </Link>
                    </Button>
                </Card>
                </div>
            </div>
            </CardContent>
        </Card>
    )
}
