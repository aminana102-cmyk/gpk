
'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const steps = [
  'From the home screen of your device, hover over the Find option.',
  'Click on Search and type "Downloader".',
  'Select the Downloader app and install it.',
  'Go back to the home screen, go to Settings > My Fire TV > Developer Options > Install unknown apps and turn it ON for Downloader.',
  'Launch the Downloader app and enter the code for your desired player.',
  'Wait for the download to finish, then click Install.',
  'Open the player app and enter the M3U link or Xtream Codes provided in your subscription email.',
];

const playerCodes = [
    { name: "IPTV Smarters Pro", code: "6468112" },
    { name: "Tivimate", code: "272483" },
    { name: "IBO Player Pro", code: "923441" },
]

export function AmazonFirestickGuide() {
    return (
        <Card className="bg-card/50">
            <CardHeader>
            <CardTitle className="text-2xl font-headline text-primary">
                Setup on Amazon Firestick
            </CardTitle>
            </CardHeader>
            <CardContent>
            <div className="space-y-4">
                {steps.map((step, index) => (
                    <div key={index} className="flex gap-4">
                    <div className="flex-shrink-0 h-8 w-8 rounded-full bg-orange-500 text-white flex items-center justify-center font-bold">
                        {index + 1}
                    </div>
                    <p className="text-foreground/90">{step}</p>
                    </div>
                ))}
                 <div className="pl-12 space-y-3 pt-2">
                    {playerCodes.map(player => (
                         <div key={player.name} className="flex items-center gap-3">
                            <p className="font-semibold text-card-foreground">{player.name}:</p>
                            <Badge variant="secondary" className="text-base">{player.code}</Badge>
                         </div>
                    ))}
                </div>
            </div>
            </CardContent>
        </Card>
    )
}
