
'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

const IPTV_SMARTERS_PRO_LINK = "https://www.iptvsmarters.com/download/?download=windows";

const steps = [
  'Download and install an IPTV player for Windows. We recommend "IPTV Smarters Pro" or "VLC Media Player".',
  'For IPTV Smarters Pro, launch the application after installation.',
  'Choose "Login with Xtream Codes API" or "Load Your Playlist / File/URL".',
  'Enter the credentials that were emailed to you by IPTV THE FOX.',
  'If using VLC, open the player, click "Media" > "Open Network Stream", and paste your M3U URL.',
  'Your channels will load, and you can begin streaming.',
];

export function WindowsGuide() {
    return (
        <Card className="bg-card/50">
            <CardHeader>
            <CardTitle className="text-2xl font-headline text-primary">
                Setup on Windows PC/Laptop
            </CardTitle>
            </CardHeader>
            <CardContent>
            <div className="space-y-4">
                {steps.map((step, index) => (
                    <div key={index} className="flex gap-4">
                    <div className="flex-shrink-0 h-8 w-8 rounded-full bg-orange-500 text-white flex items-center justify-center font-bold">
                        {index + 1}
                    </div>
                    <p className="text-foreground/90">{step}</p>
                    </div>
                ))}
                <div className="pl-12 pt-4">
                <Card className='p-4 bg-background/50'>
                    <p className='text-sm text-foreground/80 mb-2'>Download IPTV Smarters Pro for Windows directly:</p>
                    <Button asChild>
                        <Link href={IPTV_SMARTERS_PRO_LINK} target="_blank" rel="noopener noreferrer">
                        Download from Official Site
                        </Link>
                    </Button>
                </Card>
                </div>
            </div>
            </CardContent>
        </Card>
    )
}
