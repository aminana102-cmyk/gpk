
'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertTriangle } from 'lucide-react';

const steps = [
  'From your mobile phone or computer, go to my.roku.com.',
  'Log in to your Roku account.',
  'Under "Manage account", select "Add channel with a code".',
  'Enter the channel access code for "IPTV Smarters Pro" or another IPTV player and select "Add Channel".',
  'The channel will be added to your Roku device. Open it.',
  'Enter the M3U link or Xtream Codes provided in your subscription email.',
  'Start watching your favorite content.',
];

export function RokuGuide() {
    return (
        <Card className="bg-card/50">
            <CardHeader>
            <CardTitle className="text-2xl font-headline text-primary">
                Setup on Roku
            </CardTitle>
            </CardHeader>
            <CardContent>
            <div className="space-y-4">
                <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Important Note</AlertTitle>
                    <AlertDescription>
                        Roku setup requires adding a "private channel" and may not be as straightforward as other devices. We recommend using a Firestick or Android Box for the best experience.
                    </AlertDescription>
                </Alert>
                {steps.map((step, index) => (
                    <div key={index} className="flex gap-4">
                    <div className="flex-shrink-0 h-8 w-8 rounded-full bg-orange-500 text-white flex items-center justify-center font-bold">
                        {index + 1}
                    </div>
                    <p className="text-foreground/90">{step}</p>
                    </div>
                ))}
            </div>
            </CardContent>
        </Card>
    )
}
