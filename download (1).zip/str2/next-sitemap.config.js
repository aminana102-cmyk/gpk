/** @type {import('next-sitemap').IConfig} */
module.exports = {
  siteUrl: 'https://iptvthefox.tv',
  generateRobotsTxt: true,
  exclude: ['/checkout'],
  robotsTxtOptions: {
    policies: [
      {
        userAgent: '*',
        allow: '/',
        disallow: '/checkout',
      },
    ],
    additionalSitemaps: [
      'https://iptvthefox.tv/sitemap-0.xml',
    ]
  },
};
