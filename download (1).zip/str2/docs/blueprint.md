# **App Name**: SupaLegacy IPTV Hub

## Core Features:

- Homepage: Provides a landing page that introduces users to the service and provides easy navigation.
- Pricing Page: Clearly presents subscription plans with detailed feature comparisons and FAQs.
- Installation Guide: Offers comprehensive step-by-step guides with visuals to assist users in setting up the service on various devices.
- Channel List: Displays an organized and searchable list of available channels, categorized by type.
- Show highlighter: Generate a paragraph about a new or highlighted show on the service. This tool is triggered from the home page and can be sent to social media to help promote shows.
- Persistent Navigation: Implements a sticky header with links to key pages and prominent 'Get Free Trial' CTA.
- CTA Integration: Ensures all primary action buttons link to Telegram and WhatsApp contact points.

## Style Guidelines:

- Primary background: Very dark, deep purple (#120c18) for a premium feel.
- Primary accent: Fiery gradient from vibrant orange to deep red (linear-gradient(90deg, #7A7A73, #7A7A73)) for main actions and highlights.
- Heading text: Off-white with a light lavender hue (#f0e6ff) for clear and stylish headings.
- Body text: Comfortable, light grey (#a9a2b9) for readability.
- Headings: 'Poppins' (sans-serif) for a modern, technical feel. Note: currently only Google Fonts are supported.
- Body: 'Inter' (sans-serif) for a clean, highly readable style. Note: currently only Google Fonts are supported.
- Use Lucide Icons for a consistent, clean, thin-line style.
- Implement subtle fade-in or slide-up animations on scroll.